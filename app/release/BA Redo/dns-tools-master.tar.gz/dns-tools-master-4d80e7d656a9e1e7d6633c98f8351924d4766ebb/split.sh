#!/bin/bash
threads=$(grep -c ^processor /proc/cpuinfo)
file=$1
lines=`wc -l $file | cut -d' ' -f1`
date=`date +%Y-%m-%d:%H:%M:%S`
perproc=$(($lines / $threads))
filename=$(basename $file)
stats="stats/$date.json"
call="python3 adns-resolver/adns.py -ns 8.8.8.8 -ns 8.8.4.4 --statistics ${stats}"
for n in $(seq 0 $(($threads - 1))); do
        # Start process
        start=$(($n*$perproc))
        tail -n +$start $file | head -n$perproc | $call &
done
