Wrapper for ADNS and TDNS to enable multithreading and usage of central Queues
