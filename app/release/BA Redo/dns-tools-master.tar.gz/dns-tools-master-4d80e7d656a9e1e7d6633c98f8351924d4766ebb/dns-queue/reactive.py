import subprocess
import sys
import os
import multiprocessing
import atexit
import errno
import json
import fcntl

from queue import Queue

from select import select

from reactive.argparser import ArgParser

from twisted.internet import reactor
from twisted.internet import task
from twisted.python import log


class ReactiveQueue(object):
    fifo = None
    args = None
    rules = []
    processed = 0
    stdcount = 0
    call = None
    buf = ""

    def non_block_read_byte(self, output):
        fd = output.fileno()
        fl = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
        try:
            return output.read(1)
        except:
            return False

    def fill_buf(self, output):
        while True:
            nbyte = self.non_block_read_byte(output)
            if not nbyte:
                return False
            elif nbyte == "\n":
                b = self.buf
                self.buf = ""
                return b
            else:
                self.buf += nbyte

    def non_block_readline(self, output):
        line = self.fill_buf(output)
        if line:
            return line
        return False

    def __init__(self, args):
        log.startLogging(open("reactive.log", "w"), setStdout=False)
        self.args = args
        self.rules = []
        self.call = args.call
        self.proc = None
        self.issued = 0
        self.results = 0
        self.queue = Queue()
        # Parse Rules
        for rs in args.rule:
            r = rs.split(";")
            if len(r) != 5:
                log.err("Invalid rule: " + rs)
                continue
            rule = {}
            rule["status"] = r[0].split(",")
            if len(rule["status"][0]) == 0:
                rule["status"] = ["NOERROR"]
            rule["type"] = r[1].split(",")
            if len(rule["type"][0]) == 0:
                rule["type"] = ["A"]
            rule["cont"] = r[2].split(",")
            if len(rule["cont"][0]) == 0:
                rule["cont"] = []
            rule["ncont"] = r[3].split(",")
            if len(rule["ncont"][0]) == 0:
                rule["ncont"] = []
            rule["format"] = r[4].split(",")
            self.rules.append(rule)
        # Start subprocess
        self.proc = subprocess.Popen(self.call, stdout=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)

    def stdRead(self):
        for line in sys.stdin:
            # Read from stdin
            #r, w, e = select([sys.stdin], [], [], 0)
            #if sys.stdin in r:
            # Still content from stdin
            # log.msg("Reading from stdin...")
            #sys.stdin.readable()
            
            #line = sys.stdin.readline()
            if line:
                self.write(line)
                # Increase query number
                self.issued += 1
                self.stdcount += 1
                log.msg("Stdin: " + str(self.stdcount))
                written = True


    # Read from stdin or pipe new reactive query, handle results
    def loop(self):
        written = False       
        # Read from stdin
        """r, w, e = select([sys.stdin], [], [], 0)
        if sys.stdin in r:
            # Still content from stdin
            # log.msg("Reading from stdin...")
            #sys.stdin.readable()
            line = sys.stdin.readline()
            if line:
                self.write(line)
                # Increase query number
                self.issued += 1
                self.stdcount += 1
                log.msg("Stdin: " + str(self.stdcount))
                written = True"""

        # Results from subprocess?
        r, w, e = select([self.proc.stdout], [], [], 0)
        if self.proc.stdout in r:
            # Result from subprocess present
            log.msg("Reading from subproc")
            res = self.non_block_readline(self.proc.stdout)
            if res:
                res = res.decode().strip()
                # Increase result number
                self.results += 1
                # handle the result
                self.handle(res)
                # Reprint result            
                #log.msg("Got result " + res)
                print(res)

        # Handle requeue
        if self.queue.empty():
            #log.msg("Queue empty")
            if self.issued == self.results:
                #log.msg("All results present")
                # Got all results -> terminate
                self.proc.stdout.close()
                self.sched.stop()
                self.shutdown()
        else:
            # Still something in the queue            
            #log.msg("Something in the queue")
            try:
                query = self.queue.get(False)
                # Pipe to subprocess            
                #log.msg("Got " + query + " from Queue")
                self.write(query)
                self.issued += 1
                written = True
            except:
                # Nothing in the queue...
                #log.msg("Could not read from queue")
                self.proc.stdout.close()
                self.sched.stop()
                self.shutdown()
                return

        # Send "Deadlock avoidance" -> Fix this ?!
        if not written:
            self.write("?")
        log.msg("Issued: " + str(self.issued) + " - Results: "  + str(self.results))


    def handle(self, line):
        line = line.strip()
        # If there is something after the first JSON Object: Drop it!
        objects = line.split("}{")
        if len(objects) > 1:
            line = objects[0] + "}"
        else:
            line = objects[0]

        try:
            x = json.loads(line)
            status = x["status"]
            name = x["name"]
            #type = x["type"]

            for rule in self.rules:
                if not status in rule["status"]:
                    # Does not match
                    continue

                notmatched = False

                for cont in rule["cont"]:
                    if not cont in name:
                        notmatched = True
                        break

                for ncont in rule["ncont"]:
                    if ncont in name:
                        notmatched = True
                        break

                if notmatched:
                    continue
                #if not type in rule["type"]:
                    # Does not match
                #    return False
                # Handle answers
                answers = x["data"]["answers"]
                for record in answers:
                    rtype = record["type"]
                    if rtype in rule["type"]:
                        # Matches!
                        ans = record["answer"]
                        # Requeue all queries
                        for fstr in rule["format"]:
                            query = fstr.format(name, ans)
                            #log.msg("Want to query: " + query)
                            self.queue.put(query)
        except ValueError as e:
            # Do nothing for now: Unhandleable
            log.err(e.__str__())

    def write(self, name):
        name = name.strip()
        name +="\n"
        self.proc.stdin.write(bytes(name, "UTF-8"))
        self.proc.stdin.flush()
        log.msg("Sent: > " + name + "<")

    def shutdown(self):
        try:
            reactor.stop()
        except:
            return


if __name__ == "__main__":
    try:
        argparser = ArgParser()
        args = argparser.getParser().parse_args()

        requeue = ReactiveQueue(args)
        requeue.stdRead()
        # Start
        requeue.sched = task.LoopingCall(requeue.loop)
        #requeue.sched.start(0.00005)
        requeue.sched.start(0.01)
        reactor.run()
        #requeue.start()
        requeue.shutdown()
    except KeyboardInterrupt:
        requeue.shutdown()

    log.msg("Shutting down...")
