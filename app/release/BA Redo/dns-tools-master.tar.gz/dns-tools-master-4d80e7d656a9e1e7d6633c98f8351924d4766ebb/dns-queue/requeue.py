import subprocess
import sys
import os
import multiprocessing
import atexit
import errno
import json

from select import select

from requeue.argparser import ArgParser

from twisted.internet import reactor
from twisted.internet import task
from twisted.python import log


class ReQueue(object):
    fifo = None
    args = None
    rules = []
    processed = 0

    def __init__(self, args):
        log.startLogging(open("requeue.log", "w"), setStdout=False)
        FIFO = "dnsrequeue.fifo"
        try:
            os.mkfifo(FIFO)
        except OSError as oe:
            if oe.errno != errno.EEXIST:
                raise
        self.fifo = open(FIFO, "w")
        self.args = args
        self.rules = []
        for rs in args.rule:
            r = rs.split(";")
            rule = {}
            rule["status"] = r[0].split(",")
            if len(rule["status"][0]) == 0:
                rule["status"] = ["NOERROR"]
            rule["type"] = r[1].split(",")
            if len(rule["type"][0]) == 0:
                rule["type"] = ["A"]
            rule["cont"] = r[2].split(",")
            if len(rule["cont"][0]) == 0:
                rule["cont"] = []
            rule["ncont"] = r[3].split(",")
            if len(rule["ncont"][0]) == 0:
                rule["ncont"] = []
            rule["format"] = r[4].split(",")
            self.rules.append(rule)


    def start(self):
        #for line in sys.stdin:
        if True:
            log.msg("Start called")
            r, w, e = select([sys.stdin], [], [], 0)
            if not sys.stdin in r:
                log.msg("Cannot read right now...")
                return
            log.msg("There should be something to read...")
            try:
                line = sys.stdin.readline()
            except BrokenPipeError:
                log.msg("STDIN CLOSED - BROKEN PIPE")
                self.sched.stop()
                reactor.stop()
                return

            if line == None:
                log.msg("LINE WAS NONE?!")
                self.sched.stop()
                reactor.stop()
                return
            log.msg("Read line")
            # Reprint result
            line = line.strip()
            print(line)
            log.msg("Line was: " + line)
            sys.stdout.flush()

            try:
                if not self.handle(line):
                    try:
                        self.fifo.write(str(self.processed)+"\n")
                        self.fifo.flush()
                    except BrokenPipeError:
                        log.msg("Broken FIFO in handler - this should not happen...")
                        self.sched.stop()
                        reactor.stop()
                    except:
                        e = sys.exc_info()[0]
                        log.err(e)
            except BrokenPipeError:
                log.msg("FIFO was closed. I should shutdown now?!")
                self.sched.stop()
                reactor.stop()


    def handle(self, line):
        line = line.strip()
        self.processed += 1
        # If there is something after the first JSON Object: Drop it!
        objects = line.split("}{")
        if len(objects) > 1:
            line = objects[0] + "}"
        else:
            line = objects[0]

        try:
            x = json.loads(line)
            status = x["status"]
            name = x["name"]
            #type = x["type"]
            matched = False

            for rule in self.rules:
                if not status in rule["status"]:
                    # Does not match
                    continue

                notmatched = False

                for cont in rule["cont"]:
                    if not cont in name:
                        notmatched = True
                        break

                for ncont in rule["ncont"]:
                    if ncont in name:
                        notmatched = True
                        break

                if notmatched:
                    continue
                #if not type in rule["type"]:
                    # Does not match
                #    return False
                # Handle answers
                answers = x["data"]["answers"]
                for record in answers:
                    rtype = record["type"]
                    if rtype in rule["type"]:
                        # Matches!
                        ans = record["answer"]
                        # Requeue all queries
                        for fstr in rule["format"]:
                            query = fstr.format(name, ans)
                            query = str(self.processed) + " " + query + "\n"
                            log.msg("Want to query: " + query)
                            self.fifo.write(query)
                            log.msg("Queried: " + query)
                            #print(query)
                        matched = True
                        self.fifo.flush()
            return matched

        except ValueError as e:
            # Do nothing for now: Unhandleable
            print(e.__str__())

        return False

    def shutdown(self):
        try:
            self.fifo.close()
            reactor.stop()
        except:
            return


if __name__ == "__main__":
    try:
        argparser = ArgParser()
        args = argparser.getParser().parse_args()

        requeue = ReQueue(args)
        # Start
        requeue.sched = task.LoopingCall(requeue.start)
        #requeue.sched.start(0.00005)
        requeue.sched.start(0.5)
        reactor.run()
        #requeue.start()
        requeue.shutdown()
    except KeyboardInterrupt:
        requeue.shutdown()

    log.msg("Shutting down...")
