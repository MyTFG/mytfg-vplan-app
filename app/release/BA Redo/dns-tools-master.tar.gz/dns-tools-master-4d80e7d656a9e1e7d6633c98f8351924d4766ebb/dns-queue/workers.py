import subprocess
import sys
import os
import multiprocessing
import atexit
import zmq

from time import sleep
from twisted.internet import task
from twisted.internet import reactor
from twisted.python import log

# TODOS: 
#   - Use scheduler instead of sleep -> DONE
#   - Use multiple threads?
#   - Use (remote) queue [RABBITMQ] instead of stdin
#   - Replace blind param passing by "intelligent" param passing

class DnsWorkers(object):
    def __init__(self):
        self.proc = []
        self.buffer = 10
        self.current = 0
        self.dir = os.path.dirname(os.path.realpath(__file__))
        self.call = self.dir+"/../tdns-resolver/tdns.py"

        log.startLogging(sys.stderr, setStdout=False)

        context = zmq.Context()
        self.queue = context.socket(zmq.PUSH)
        self.queue.bind("tcp://127.0.0.1:5557")

        self.params = sys.argv[2:]
        self.params.append("--zmq")
        self.params.append("--zmqnofill")
        self.threads = multiprocessing.cpu_count()
        self.threads = int(sys.argv[1])
        self.cmd = ["python3", self.call]+self.params
        self.simult = 4

    def start(self):
        #self.sched = task.LoopingCall(self.fillQueue)

        # Start multiple processes
        for x in range(self.threads):
            #call = ["taskset", "-c", str(x)]+self.cmd
            call=self.cmd
            # Splits the pipe to all subprocesses
            self.proc.append(subprocess.Popen(call, stdout=None, stdin=None))

        #self.sched.start(0.00005 / self.threads)


        for line in sys.stdin:
            line = line.strip()
            #if not line:
            #    self.closeQueue()
            self.queue.send_string(line)

        self.wait()

        #reactor.run()

    def fillQueue(self):
        line = sys.stdin.readline()
        #log.msg("Got line: " + line)
        if not line:
            self.closeQueue()
            return
        self.queue.send_string(line)
        # Check if children are still running
        for i, p in enumerate(self.proc):
            if p.poll() != None:
                # Restart terminated subprocess
                log.msg("Restarting terminated subprocess " + i)
                self.proc[i] = subprocess.Popen(call, stdout=None, stdin=None)
        
    def closeQueue(self):
        log.msg("Closing Queue")
        #self.sched.stop()
        #reactor.stop()
        return

    def wait(self):
        log.msg("Waiting")
        exit_codes = [p.wait() for p in self.proc]
        self.queue.close()
        return exit_codes

    def cleanup(self):
        for p in self.proc:
            p.kill()


if __name__ == "__main__":
    try:
        queue = DnsWorkers()
        # Register exit handler
        atexit.register(queue.cleanup)
        # Start subprocesses
        queue.start()
        # Wait for subprocesses
        codes = queue.wait()
    except KeyboardInterrupt:
        queue.cleanup()
        sys.exit(0)
