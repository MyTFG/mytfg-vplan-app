import argparse

class ArgParser(object):
    def __init__(self):
        self.progname = "DNS-Requeue"
        self.versionstr = "0.2"
        self.progversion = "{0} {1}".format(self.progname, self.versionstr)
        self.parser = argparse.ArgumentParser(description="Define requeue conditions for DNS results", prog=self.progname)

        self.rule()

        #self.status()
        #self.qtype()
        #self.rtype()
        #self.formatStrings()

    def getParser(self):
        return self.parser

    def rule(self):
        p = self.parser
        p.add_argument("--rule", "-r", action="append", default=[],
            help="Requeue Rules. 'STATUS;A;contains;containsnot;{0} AAAA'")

    def status(self):
        p = self.parser
        p.add_argument("--status", "-s", action="append", default=[],
            help="Matching Response Status. May be specified multiple times. Default: NOERROR")

    def qtype(self):
        p = self.parser
        p.add_argument("--qtype", "-qt", action="append", default=[],
            help="Matching Query Type. May be specified multiple times. Default: A")

    def rtype(self):
        p = self.parser
        p.add_argument("--rtype", "-rt", action="append", default=[],
            help="Matching Response Type. May be specified multiple times. Default: A")

    def formatStrings(self):
        p = self.parser
        p.add_argument("--formatStr", "-f", action="append", default=[],
            help="Format String for next name. {0} is queried name, {1} is answer. Default: {0} AAAA")


