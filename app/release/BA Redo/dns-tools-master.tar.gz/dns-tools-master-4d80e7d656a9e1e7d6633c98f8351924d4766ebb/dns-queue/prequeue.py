import subprocess
import sys
import os
import multiprocessing
import atexit
import errno
import time
from select import select

from twisted.internet import reactor
from twisted.internet import task
from twisted.python import log

# TODOS: 
#   - Use scheduler instead of sleep -> DONE
#   - Use multiple threads?
#   - Use (remote) queue [RABBITMQ] instead of stdin
#   - Replace blind param passing by "intelligent" param passing

class DnsPreQueue(object):
    def __init__(self):
        self.queries = 0
        log.startLogging(open("prequeue.log", "w"), setStdout=False)
        self.sched = None
        self.fifo = False
        self.FIFO = "dnsrequeue.fifo"
        self.log = open("preq.log", "w")
        #self.lastread = time.time()
        #self.timeout = 5
        try:
            os.mkfifo(self.FIFO)
        except OSError as oe:
            if oe.errno != errno.EEXIST:
                raise

    def stdinread(self):
        for line in sys.stdin:
            self.queries+=1
            log.msg(line)
            print(line.strip(), flush=True)
            sys.stdout.flush()

    def popfifo(self):
        self.fifo = open(self.FIFO, "r")
        #while True:
        if True:
     #      for line in self.fifo:
            r, w, e = select([self.fifo], [], [], 3)
            if not self.fifo in r:
                #if self.lastread < time.time() - timeout:
                #   break
                return
                #continue
            #self.lastread = time.time()
            line = self.fifo.readline().strip()
            cmd=line.split(" ")
            num=cmd[0]
            if len(cmd) > 1:
                name = cmd[1]
                log.msg(name + " - " + str(cmd))
                if len(cmd) > 2:
                    types = cmd[2:]
                    for t in types:
                        self.queries+=1
                        print(name + " " + t)
                        log.msg(name + " " + t)
                else:
                    self.queries+=1
                    print(name)
            sys.stdout.flush()
            log.msg(num + " / " + str(self.queries))
            if int(num) == self.queries:
                log.msg("I should shutdown now!")
                self.sched.stop()
                reactor.stop()
            else:
                log.msg("Still something todo: " + num + " / " + str(self.queries))
        return

    def cleanup(self):
        log.msg("Cleanup")
        if self.fifo != False:
            self.fifo.close()
        if reactor.running:
            reactor.stop()

if __name__ == "__main__":
    queue = False
    try:
        queue = DnsPreQueue()
        # Register exit handler
        atexit.register(queue.cleanup)
        # Start subprocesses
        queue.stdinread()
        #queue.popfifo()
        sched = task.LoopingCall(queue.popfifo)
        queue.sched = sched
        sched.start(0.00005)
        reactor.run()
        queue.cleanup()
    except KeyboardInterrupt:
        if (queue):
            queue.cleanup()
    log.msg("Will exit now")
