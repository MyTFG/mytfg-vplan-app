#DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LENGTH="1000"

CMD="/root/work/bin/zdns"
PARAMS="A --name-servers 8.8.8.8:53 8.8.4.4:53"
INPUT="cat $1"

DNS="${INPUT} | ${CMD} ${PARAMS}"

FULL="${DNS}"

eval $FULL 
