DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
#NS="$(getent hosts ipv4.rleh.de | awk '{print $1}')"
ADNS="python3.4 /root/Documents/ba/adns-resolver/adns.py"
#NS="188.68.58.202"
NS1="127.0.0.1"
NS2="8.8.8.8"
NS3="8.8.4.4"
time $ADNS -i ${DIR}/../source/100000.txt --tries 2 --timeout 10 -ns ${NS2} -ns ${NS3} --rotate --ec --lib twisted

