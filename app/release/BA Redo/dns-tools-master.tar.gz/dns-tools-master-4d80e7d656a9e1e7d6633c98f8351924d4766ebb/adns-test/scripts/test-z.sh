DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
NS="$(getent hosts ipv4.rleh.de | awk '{print $1}')"
ZDNS="/root/work/bin/zdns"
#NS="188.68.58.202"
NS="127.0.0.1"
NS2="8.8.8.8"
NS3="8.8.4.4"
time cat ${DIR}/../source/100000.txt | $ZDNS A --name-servers ${NS2}:53 ${NS3}:53 --threads 1000
