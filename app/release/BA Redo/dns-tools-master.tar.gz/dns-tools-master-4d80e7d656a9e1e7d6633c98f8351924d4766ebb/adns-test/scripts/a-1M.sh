#DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

PY="/usr/bin/python3.4"
LENGTH="1000"

CMD="${PY} /root/Documents/ba/adns-resolver/adns.py"
PARAMS="--lib pycares -ns 8.8.8.8 -ns 8.8.4.4 --timeout 5 --tries 1"
INPUT="-i $1"

DNS="${CMD} ${PARAMS} ${INPUT}"

FULL="${DNS}"

eval $FULL 
