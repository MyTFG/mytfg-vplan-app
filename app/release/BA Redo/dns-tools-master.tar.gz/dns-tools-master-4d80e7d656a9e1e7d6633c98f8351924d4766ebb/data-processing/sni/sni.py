import argparse
from hashmap import Hashmap
from dictmap import Dictmap
import ujson as json
#import yajl as json
import sys
import time

def printd(val, args):
    if args.debug:
        print(val)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SNI support for Portscans", prog="SNI MAP")

    parser.add_argument("--format", "-f", action="store", default="{0},{1}",  
        help="Output format. {0} represents the IP address, {1} is the domain name")
    parser.add_argument("--keynum", "-n", action="store", default="28",
        type=int,
        help="Bitlength for keys. Use lower values when less IPs are stored")
    parser.add_argument("--file", "-if", action="store",
        help="File containing scan results in JSON format")
    parser.add_argument("--mapfile", "-mf", action="store",
        help="File to save the hashmap to. If --file is not used, this mapfile is used as source as well")
    parser.add_argument("--debug", "-d", action="store_true",
        help="Set to enable debug output")


    args = parser.parse_args()
    if not args.file:
        args.load = True
    else:
        args.load = False

    startt = time.time()

    try:
        printd("Creating Hashmap...", args)
        hashmap = Dictmap(args)
        printd("Created Hashmap", args)
        count = 0
        maxcount = 0
        lcount = 0
        if args.file:
            startf = time.time()
            jsontime = 0
            printd("Building Map from input file", args)
            with open(args.file, "r") as f:
                for line in f:
                    lcount += 1
                    startj = time.time()
                    try:
                        entry = json.loads(line)
                    except ValueError:
                        continue
                    jsontime += time.time() - startj
                    dom = entry["name"]
                    qtype = entry["type"]
                    if qtype != "A":
                        continue

                    answers = entry["data"]["answers"]
                    for r in answers:
                        if r["type"] == "A":
                            maxcount += 1
                            if hashmap.put(r["answer"], dom):
                                count += 1
                    if lcount % 100000 == 0:
                        endf = time.time()
                        avg = count / (endf - startf)
                        avg2 = maxcount / (endf - startf)
                        avg3 = lcount / (endf - startf)
                        jsperf = jsontime / (endf - startf)
                        printd("Done: " + str(count) + "/" + str(maxcount) + "  (" + str(lcount) + " lines)", args)
                        printd("  " + str(avg) + " succ. puts / s ("+str(avg2)+" puts /s)", args)
                        printd("  " + str(avg3) + " lines / s", args)
                        printd("  " + str(jsperf) + "% JSON parsing", args)
                        
            printd("Map complete. Count: " + str(count) + " of " + str(maxcount), args)
            printd("Saving Map", args)
            hashmap.save()
            printd("Saved Map", args)

        prepduration = time.time() - startt

        printd("Starting SNI reverse lookup", args)
        startt = time.time()
        count = 0
        for line in sys.stdin:
            ip = line.strip()
            dom = hashmap.get(ip)
            print(args.format.format(ip, dom))
            count += 1                

        endt = time.time()
        duration = endt - startt
        printd(str(prepduration) + "s needed for preparations", args)
        printd(str(duration) + "s needed for looking up " + str(count) + " entries", args)
        average = count / duration
        printd("  This is " + str(average) + "entries per second", args)
        printd("Finished", args)
    except KeyboardInterrupt:
        printd("Interrupted (SIGINT)", args)