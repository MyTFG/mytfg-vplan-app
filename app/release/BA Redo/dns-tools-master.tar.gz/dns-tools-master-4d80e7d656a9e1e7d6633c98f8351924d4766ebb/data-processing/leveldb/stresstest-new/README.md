# Stresstest for LevelDB
## Steps
1. Run "collectQueries" to collect IPs from the database and mix them up. This will also add some non-existent IPs
2. Run "stresstest" to perform a stresstest. This will query all IPs from step 1 from LevelDB and test the performance
