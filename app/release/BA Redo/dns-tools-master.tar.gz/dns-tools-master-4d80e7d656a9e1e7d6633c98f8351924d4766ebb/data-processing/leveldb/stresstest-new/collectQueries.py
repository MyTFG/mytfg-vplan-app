import plyvel
import sys
import random
import socket
import struct

def zfill(part):
    return part.zfill(3)

def padip(ip):
    iplist = ip.split(".")
    iplist = map(zfill, iplist)
    return ".".join(iplist)

def ip2int(addr):                                                               
    return struct.unpack("!I", socket.inet_aton(addr))[0]                       


def int2ip(addr):                                                               
    return socket.inet_ntoa(hex(ip)[2:].zfill(8).decode('hex'))

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Not enough arguments. Usage:")
        print("collectQueries.py LEVELDB NUMIPs STOREDIPs")
        print("  LEVELDB:   LevelDB data dir")
        print("  NUMIPs:    Number of IPs to collect")
        print("  STOREDIPs: Approximation of number of IPs in the LevelDB")
        sys.exit()

    # Loop all stored IPs
    done = 0
    max = int(sys.argv[2])
    stored = int(sys.argv[3])
    prop = max
    # Only 90% of IPs are really stored - rest will be random
    maxstored = 0.9 * max
    lastip = None
    db = plyvel.DB(sys.argv[1], create_if_missing=False)
    for key, value in db:
        split = key.decode().split("!")
        ip = int(split[0], 2)
        if ip == lastip:
            continue
        lastip = ip
        reformatted = socket.inet_ntoa(struct.pack('>I', ip))
        # Use this IP?
        if done < maxstored and random.randint(0,stored) < prop:
            done += 1
            print(reformatted)
        if done >= maxstored:
            break
    # Add random IPs?
    while done < max:
        print(socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff))))
        done += 1
