import plyvel
import sys
import ipaddress
import random

#from classes.argparser import ArgParser
#from tools.multiusage import MultiUsage

def zfill(part):
    return part.zfill(32)


def ipob2str(ipob):
    return format(int(ipob), '#034b')

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=False)

    for line in sys.stdin:
        line = line.strip()

        ipob = ipaddress.ip_address(line)
        prefix = ipob2str(ipob)
        results = []
        for key, value in db.iterator(prefix=prefix.encode()):
            results.append(value.decode())
        if len(results) == 0:
            print(line + "," + line)
        else:
            name = random.choice(results)
            print(line + "," + name)

    db.close()
