import plyvel
import sys
import ipaddress

#from classes.argparser import ArgParser
#from tools.multiusage import MultiUsage

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=False)

    for line in sys.stdin:
        line = line.strip().lower()
        for key, value in db.iterator(prefix=line.encode()):
            print(value.decode())
    db.close()
