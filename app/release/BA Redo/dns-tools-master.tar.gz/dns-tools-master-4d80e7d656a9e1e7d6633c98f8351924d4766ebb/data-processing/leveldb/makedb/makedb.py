import plyvel
import fileinput
import json
import sys
import socket
import ipaddress

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=True)
    key_num = 0
    i = 0
    for line in sys.stdin:
        line = line.strip()
        # If there is something after the first JSON Object: Drop it!
        objects = line.split("}{")
        if len(objects) > 1:
            line = objects[0] + "}"
        else:
            line = objects[0]
        i+=1
        if (line == ""):
            continue

        try:
            x = json.loads(line)
        except ValueError as e:
            raise Exception(str(i) + ": " + line)

        status = x["status"]
        if (status != "NOERROR"):
            continue

        # Extract domain
        name = x["name"].lower()
        key = name + "!" + str(key_num)
        db.put(key.encode(), line.encode())
        # Inc key
        key_num += 1
        if i % 100000 == 0:
            print("Done: " + str(i))
    
    # Close DB
    db.close()

