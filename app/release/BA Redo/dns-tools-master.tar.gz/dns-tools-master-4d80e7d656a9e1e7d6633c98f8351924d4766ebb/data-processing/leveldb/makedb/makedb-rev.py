import plyvel
import fileinput
import json
import sys
import socket
import ipaddress

def zfill(part):
    return part.zfill(32)

def ipob2str(ipob):
    return format(int(ipob), '#034b')

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=True)
    key_num = 0
    i = 0
    for line in sys.stdin:
        line = line.strip()
        # If there is something after the first JSON Object: Drop it!
        objects = line.split("}{")
        if len(objects) > 1:
            line = objects[0] + "}"
        else:
            line = objects[0]
        i+=1
        if (line == ""):
            continue

        try:
            x = json.loads(line)
        except ValueError as e:
            raise Exception(str(i) + ": " + line)

        status = x["status"]
        if (status != "NOERROR"):
            continue

        answers = x["data"]["answers"]
        # Gather all A / AAAA records in answer section
        for record in answers:
            rtype = record["type"]
            if (rtype == "A" or rtype == "AAAA"):
                # Extract IP and name, map ip->name
                strip = record["answer"]
                ipob = ipaddress.ip_address(strip)
                keystr = ipob2str(ipob)+"!"+str(key_num)
                #keystr = (bin(int(ipob)))+"!"+str(key_num)
                key = keystr.encode()

                #key = socket.inet_aton(ip)
                #print(key)
                #print(key.encode())
                name = record["name"]
                #key = padip(ip) + "!" + str(key_num)
                db.put(key, name.encode())
                key_num += 1
        if i % 100000 == 0:
            print("Done: " + str(i))
            print("   " + keystr)
            print("   " + strip)
    # Write Batch finished
    #wb.write()

    # Close DB
    db.close()

