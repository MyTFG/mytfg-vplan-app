import ujson as json
import sys

"""
Allows to extract domains that use the given ASN in the given category 
and provide IPv6 records 
"""
asns = {
    "root": [],
    "www": [],
    "mx": [],
    "ns": [],
    "all": []
}

searchAsn = int(sys.argv[1]) # The AS number
searchCat = sys.argv[2] # mx, ns, www, root

for line in sys.stdin:
    res = json.loads(line)
    try:
        dom = res["domain"]
        asns = res["zAnalysis"]["ipv6Asns"]
        if searchAsn in asns:
            s = res["summary"]
            # Check if ASN is used for the given aspect
            if searchCat in ["www", "root"]:
                if searchAsn == s[searchCat]["asn"] and s[searchCat]["v6ready"]:
                    if searchCat == "www":
                        subDom = "www." + dom
                    else:
                        subDom = dom
                    print(dom + " - " + subDom + " - " + s[searchCat]["ipv4"])
            elif searchCat in ["mx", "ns"]:
                for entry in s[searchCat]["results"]:
                    if entry["asn"] == searchAsn and entry["v6ready"]:
                        print(dom + " - " + entry["name"] + " - " + entry["ipv4"])
    except KeyError as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        print("KeyError: " + e.__str__())