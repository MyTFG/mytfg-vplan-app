import ujson as json
import sys
import ipaddress

"""
Allows to extract all IPv6 capable IPv4 addresses / hosts from a given IPv6-capability scan
"""
with open(sys.argv[1], "r") as f:
    hosts = json.load(f)

with open(sys.argv[2], "r") as f:
    subnets = json.load(f)

result = {}

for line in sys.stdin:
    res = json.loads(line)
    #try:              
    dom = res["domain"]

    out = {
        "name": dom,
        "rootV6": res["summary"]["root"]["v6ready"],
        "wwwV6": res["summary"]["www"]["v6ready"],
        "v6": res["zgradenum"] < 3,
        "asnFixable": res["zAnalysis"]["fixable"],
        "subnetFixabe": False,
        "hostFixable": False,
        "www": {
            "v6ready": res["summary"]["www"]["v6ready"],
            "asnFixable": False,
            "subnetFixable": False,
            "hostFixable": False,
            "ipv4": res["summary"]["www"]["ipv4"],
            "asn": res["summary"]["www"]["asn"]
        },
        "root": {
            "v6ready": res["summary"]["root"]["v6ready"],
            "asnFixable": False,
            "subnetFixable": False,
            "hostFixable": False,
            "ipv4": res["summary"]["root"]["ipv4"],
            "asn": res["summary"]["root"]["asn"]
        },
        "mx": {
            "v6ready": res["summary"]["mx"]["any6"],
            "asnFixable": False,
            "subnetFixable": False,
            "hostFixable": False,
            "problem": res["zAnalysis"]["state"]["mx"]["problem"]
        },
        "ns": {
            "v6ready": res["summary"]["ns"]["any6"],
            "asnFixable": False,
            "subnetFixable": False,
            "hostFixable": False
        },
    }

    # Extract root and www
    for t in ["root", "www"]:
        out[t]["asnFixable"] = res["zAnalysis"]["state"][t]["fixable"]
        ip = res["summary"][t]["ipv4"]
        if len(ip) == 0:
            continue

        subnet = str(ipaddress.ip_network(ip + "/21", False))

        if subnet in subnets:
            if t in subnets[subnet]["types"]:
                out[t]["subnetFixable"] = True
        if ip in hosts:
            if t in hosts[ip]["types"]:
                out[t]["hostFixable"] = True

    # Extract ns and mx
    for t in ["ns", "mx"]:
        out[t]["asnFixable"] = res["zAnalysis"]["state"][t]["fixable"]
        for r in res["summary"][t]["results"]:
            if not r["v6ready"]:
                ip = r["ipv4"]
                if len(ip) == 0:
                    continue
                subnet = str(ipaddress.ip_network(ip + "/21", False))
                if ip in hosts:
                    if t in hosts[ip]["types"]:
                        out[t]["hostFixable"] = True
                if subnet in subnets:
                    if t in subnets[subnet]["types"]:
                        out[t]["subnetFixable"] = True

    out["subnetFixable"] = out["root"]["subnetFixable"] and out["www"]["subnetFixable"]
    out["hostFixable"] = out["root"]["hostFixable"] and out["www"]["hostFixable"]
    result[dom] = out

print(json.dumps(result))

