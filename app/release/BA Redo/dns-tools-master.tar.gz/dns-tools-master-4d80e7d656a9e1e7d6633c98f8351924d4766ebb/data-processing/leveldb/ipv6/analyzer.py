import plyvel
import ujson as json
import pyasn
from reasoner import Reasoner



class Ipv6Analyzer:
    def __init__(self, db, asnfile = False, asnListFile = False):
        #print("Init")
        self.db = db
        self.points = 0
        self.maxpoints = 0
        self.nsList = []
        self.capableAsns = []
        if not asnfile:
            self.doAsn = False
        else:
            self.asndb = pyasn.pyasn(asnfile)
            self.doAsn = True

        if not asnListFile:
            self.asnList = False
        else:
            with open(asnListFile) as f:
                self.asnList = f.read().splitlines()
                self.asnList = "".join(self.asnList)
                self.asnList = json.loads(self.asnList)


    def analyze(self, dom):
        """
        Hierarchy:
        Check domain (A)
            www A
                AAAA
            AAAA
            NS
                AAAA
            MX
                AAAA
        """
        self.points = 0
        self.maxpoints = 0
        # If this is true, the domain is not IPv6 capable at all
        self.totalfail = False
        self.res = {
            "domain": dom,
            "log": [],
            "msg": [],
            "fatal": [],
            "warn": [],
            "err": [],
            "lags": [],
            "summary": {
                "mx": {
                    "found": False,
                    "results": [],
                    "any6": False,
                    "any4": False,
                    "num": 0,
                    "v6num": 0
                },
                "ns": {
                    "found": False,
                    "results": [],
                    "any6": False,
                    "any4": False,
                    "num": 0,
                    "v6num": 0
                },
                "www": {
                    "v4ready": False,
                    "v6ready": False,
                    "asn": -1,
                    "ipv4": "",
                    "ipv6": ""
                },
                "root": {
                    "v4ready": False,
                    "v6ready": False,
                    "asn": -1,
                    "ipv4": "",
                    "ipv6": ""
                }
            },
            "zstars": 0,
            "zmaxstarts": 5,
            "fixes": []
        }
        #print("Get Dom")
        main = self.getDomain(dom, ["A", "AAAA", "MX", "NS"], 120)
        #print("Get Dom www")
        www = self.getDomain("www."+dom, ["A", "AAAA"], 40)
        #print("Filter")
        ns = self.filter(main, "NS")
        mx = self.filter(main, "MX")
        a = self.filter(main, "A")
        a4 = self.filter(main, "AAAA")

        # Check All aspects
        #print("Check A")
        self.checkIpv4(a)
        #print("Check A4")
        self.checkIpv6Base(a4)
        #print("Check NS")
        nameservers = self.checkNs(ns)
        #print("Check NS4")
        self.checkNsIpv4(nameservers)
        #print("Check NS6")
        self.checkNsIpv6(nameservers)
        #print("Check WWW")
        self.checkWWW(www)
        #print("Check MX")
        self.checkMX(mx)

        # Do ASN Analysis
        if self.doAsn:
            self.checkAsn()

        # Grade
        if self.totalfail:
            grade = "Not IPv6 capable."
            gradenum = 6
            self.res["zreason"] = ", ".join(self.res["fatal"])
        elif self.points == self.maxpoints:
            grade = "Perfectly IPv6 compatible"
            gradenum = 1
        else:
            grade = "IPv6 compatible"
            gradenum = 2
            self.res["zreason"] = ", ".join(self.res["err"])

        # Stars
        ## IPv6 main: 1
        ## IPv6 www or no www at all: 1
        ## IPv6 Any NS: 1
        ## IPv6 More than 1 NS: 0.5
        ## IPv6 Any MX: 1
        ## IPv6 More than 1 MX: 0.5
        stars = 0
        if self.res["summary"]["root"]["v6ready"]:
            stars += 1
        # WWW
        if self.res["summary"]["www"]["v4ready"]:
            if self.res["summary"]["www"]["v6ready"]:
                stars += 1
        else:
            self.warn("No www subdomain found")
            stars += 1
        # NS
        if self.res["summary"]["ns"]["any6"]:
            stars += 1
        if self.res["summary"]["ns"]["v6num"] > 1:
            stars += 0.5
        else:
            self.warn("No IPv6 fallback NS available")
        # MX
        if self.res["summary"]["mx"]["any6"]:
            stars += 1
        if self.res["summary"]["mx"]["v6num"] > 1:
            stars += 0.5
        else:
            self.warn("No IPv6 fallback MX available")
        self.res["zstars"] = stars

        # Summarize
        self.res["points"] = self.points
        self.res["max_points"] = self.maxpoints
        self.res["status"] = str(self.points) + " / " + str(self.maxpoints)
        self.res["result"] = self.points == self.maxpoints
        # zGrade: Move grade to the bottom ;)
        self.res["zgrade"] = grade
        self.res["zgradenum"] = gradenum

        # Reasoning
        if self.doAsn:
            l3analysis = Reasoner.reason(self.res, self.asnList)
            self.res["zAnalysis"] = l3analysis
        else:
            self.res["zAnalysis"] = False

        # Return result
        return self.res

    #TESTS
    def checkAsn(self):
        # Root
        if self.res["summary"]["root"]["v4ready"]:
            ip = self.res["summary"]["root"]["ipv4"]
            asn = self.asndb.lookup(ip)
            self.res["summary"]["root"]["asn"] = asn[0]
        # www
        if self.res["summary"]["www"]["v4ready"]:
            ip = self.res["summary"]["www"]["ipv4"]
            asn = self.asndb.lookup(ip)
            self.res["summary"]["www"]["asn"] = asn[0]
        # NS
        nss = self.res["summary"]["ns"]["results"]
        for idx, ns in enumerate(nss):
            if ns["v4ready"]:
                ip = ns["ipv4"]
                asn = self.asndb.lookup(ip)
                self.res["summary"]["ns"]["results"][idx]["asn"] = asn[0]
        # MX
        mxs = self.res["summary"]["mx"]["results"]
        for idx, mx in enumerate(mxs):
            if mx["v4ready"]:
                ip = mx["ipv4"]
                asn = self.asndb.lookup(ip)
                self.res["summary"]["mx"]["results"][idx]["asn"] = asn[0]

    def checkMX(self, mx):
        hasMx = False
        mxList = []
        for q in mx:
            for record in q["data"]["answers"]:
                if record["type"] == "MX":
                    hasMx = True
                    srv = record["answer"]
                    if srv in mxList:
                        # Skip duplicates
                        continue
                    mxList.append(srv)
                    self.res["summary"]["mx"]["results"].append({
                        "v4ready": False,
                        "v6ready": False,
                        "asn": -1,
                        "name": srv,
                        "ipv4": "",
                        "ipv6": ""
                        })
                    self.log("MX: " + srv)
        if not hasMx:
            self.warn("Has no MX record")
        else:
            # AAAA + A
            self.maxpoints += len(mxList)*2
            self.res["summary"]["mx"]["num"] = len(mxList)

        self.res["summary"]["mx"]["found"] = hasMx
        if not hasMx:
            return

        anyMx4 = False
        anyMx6 = False
        for idx, m in enumerate(mxList):
            mxDom = self.getDomain(m, ["A", "AAAA"], 40)
            res = self.filter(mxDom, "AAAA")
            resA = self.filter(mxDom, "A")
            hasAAAA = False
            hasA = False
            for q in res:
                for record in q["data"]["answers"]:
                    if record["type"] == "AAAA":
                        hasAAAA = True
                        anyMx6 = True
                        self.points += 1
                        self.res["summary"]["mx"]["results"][idx]["ipv6"] = record["answer"]
                        self.res["summary"]["mx"]["results"][idx]["v6ready"] = True
                        self.log("MX " + q["name"] + " has AAAA record: " + record["answer"])
                        self.res["summary"]["mx"]["v6num"] += 1
                        break
                if hasAAAA:
                    break
            for q in resA:
                for record in q["data"]["answers"]:
                    if record["type"] == "A":
                        hasA = True
                        anyMx4 = True
                        self.points += 1
                        self.res["summary"]["mx"]["results"][idx]["ipv4"] = record["answer"]
                        self.res["summary"]["mx"]["results"][idx]["v4ready"] = True
                        self.log("MX " + q["name"] + " has A record: " + record["answer"])
                        break
                if hasA:
                    break
            if not hasA:
                self.warn("MX " + m + " has no A Record")
            if not hasAAAA:
                self.warn("MX " + m + " has no AAAA Record")
        if anyMx6:
            self.res["summary"]["mx"]["any6"] = True
        if anyMx4:
            self.res["summary"]["mx"]["any4"] = True
        if not anyMx6:
            self.err("No MX has AAAA Record", True)
        if not anyMx4:
            self.err("No MX has A Record", True)

    def checkWWW(self, www):
        # Check if www has A record
        hasA = False
        # For: www A
        self.maxpoints += 1
        a = self.filter(www, "A")
        for q in a:
            for record in q["data"]["answers"]:
                if record["type"] == "A":
                    self.log("www has IPv4 record: " + record["answer"])
                    hasA = True
                    self.res["summary"]["www"]["v4ready"] = True
                    self.res["summary"]["www"]["ipv4"] = record["answer"]
                    # Points: www AAAA
                    self.maxpoints += 1
                    # For: www A
                    self.points += 1
                    break
            if hasA:
                break
        # Check AAAA
        if hasA:
            aaaa = self.filter(www, "AAAA")
            for q in aaaa:
                for record in q["data"]["answers"]:
                    if record["type"] == "AAAA":
                        # For: www AAAA
                        self.points += 1
                        self.log("www has IPv6 record: " + record["answer"])
                        self.res["summary"]["www"]["v6ready"] = True
                        self.res["summary"]["www"]["ipv6"] = record["answer"]
                        return
            self.err("www is not IPv6 capable", True)
        else:
            self.warn("No A record for www present")



    def checkNsIpv6(self, nsList):
        anySrv = False 
        self.maxpoints += 1

        for idx, ns in enumerate(nsList):
            # Extract from DB
            queries = self.getDomain(ns, ["AAAA"], 40)
            # Filter AAAA
            results = self.filter(queries, "AAAA")
            found = False
            self.res["summary"]["ns"]["num"] = len(nsList)
            if len(results) > 0:
                for q in results:
                    if len(q["data"]["answers"]) > 0:
                        # There are results / answers
                        for record in q["data"]["answers"]:
                            if record["type"] == "AAAA":
                                self.points += 1
                                self.log("NS " + ns + " is IPv6 ready")
                                found = True
                                anySrv = True
                                self.res["summary"]["ns"]["results"][idx]["v6ready"] = True
                                self.res["summary"]["ns"]["results"][idx]["ipv6"] = record["answer"]
                                self.res["summary"]["ns"]["v6num"] += 1
                                break
                    if found:
                        break
                if not found:
                    self.warn("NS " + ns + " is not IPv6 ready")                    
            else:
                self.warn("NS " + ns + " is not IPv6 ready")
        if anySrv:
            self.points += 1
            self.log("At least one IPv6 capable Nameserver found")
            self.res["summary"]["ns"]["any6"] = True
        else:
            self.err("No Nameserver is IPv6 ready", True)

    def checkNsIpv4(self, nsList):
        anySrv = False 
        self.maxpoints += 1

        for idx, ns in enumerate(nsList):
            # Extract from DB
            queries = self.getDomain(ns, ["A"])
            # Filter A
            results = self.filter(queries, "A")
            found = False
            if len(results) > 0:
                for q in results:
                    if len(q["data"]["answers"]) > 0:
                        # There are results / answers
                        for record in q["data"]["answers"]:
                            if record["type"] == "A":
                                self.points += 1
                                self.log("NS " + ns + " is IPv4 ready")
                                found = True
                                anySrv = True
                                self.res["summary"]["ns"]["results"][idx]["v4ready"] = True
                                self.res["summary"]["ns"]["results"][idx]["ipv4"] = record["answer"]
                                break
                    if found:
                        break
                if not found:
                    self.err("NS " + ns + " is not IPv4 ready")                    
            else:
                self.err("NS " + ns + " is not IPv4 ready")
        if anySrv:
            self.points += 1
            self.log("At least one IPv4 capable Nameserver found")
            self.res["summary"]["ns"]["any4"] = True
        else:
            self.err("No Nameserver is IPv4 ready", True)

    def checkNs(self, ns):
        nameservers = []
        # NS Record present
        self.maxpoints += 1
        if len(ns) > 0:
            self.points += 1
            self.res["summary"]["ns"]["found"] = True
            #self.log("Nameserver Query found")
        else:
            self.res["summary"]["ns"]["found"] = False
            self.err("No Nameservers found!", True)
            return nameservers
        # Nameserver Result present?
        self.maxpoints += 1
        found = False
        # Count Nameservers
        for r in ns:
            if len(r["data"]["answers"]) > 0:
                for asn in r["data"]["answers"]:
                    if asn["type"] == "NS":
                        found = True
                        srv = asn["answer"]
                        if srv in nameservers:
                            # Skip duplicates
                            continue
                        self.res["summary"]["ns"]["results"].append({
                            "name": srv,
                            "v4ready": False,
                            "v6ready": False,
                            "asn": -1,
                            "ipv4": "",
                            "ipv6": ""
                            })
                        nameservers.append(srv)
                        self.log("Found Nameserver: " + srv)
        if found:
            self.points += 1
            # IPV6 compatibility + IPv4
            self.maxpoints += len(nameservers)*2
        else:
            self.err("No Nameservers present", True)
        return nameservers


    def checkIpv6Base(self, a4List):
        self.maxpoints += 1
        for r in a4List:
            if len(r["data"]["answers"]) > 0:
                for asn in r["data"]["answers"]:
                    if asn["type"] == "AAAA":
                        self.points += 1
                        ip = asn["answer"]
                        self.log("Domain has AAAA record: " + ip)
                        self.res["summary"]["root"]["v6ready"] = True
                        self.res["summary"]["root"]["ipv6"] = ip
                        return
        self.err("Domain has no AAAA record", True)
        self.res["summary"]["root"]["v6ready"] = False

    def checkIpv4(self, aList):
        self.maxpoints += 1
        for r in aList:
            if len(r["data"]["answers"]) > 0:
                for asn in r["data"]["answers"]:
                    if asn["type"] == "A":
                        ip = asn["answer"]
                        self.points += 1
                        self.log("Domain is IPv4 ready: " + ip)
                        self.res["summary"]["root"]["v4ready"] = True
                        self.res["summary"]["root"]["ipv4"] = ip
                        return
        self.err("Domain is not IPv4 ready - no A record", True)
        self.err("No data for domain found", True)
        self.res["summary"]["root"]["v4ready"] = False


    def filter(self, rlist, type, status="NOERROR"):
        res = []
        for data in rlist:
            # Check status
            if status == data["status"]:
                if status == "NOERROR":
                    # Check type
                    if data["type"] == type:
                        res.append(data)
                else:
                    # Other Status Message: No type!
                    res.append(data)
        return res

    def log(self, msg, error=False):
        self.res["log"].append(msg)
        if not error:
            self.res["msg"].append(msg)

    def err(self, msg, fatal=False):
        self.log(msg, True)
        self.res["err"].append(msg)
        if fatal:
            self.res["fatal"].append(msg)
            self.totalfail = True

    def warn(self, msg):
        self.log(msg)
        self.res["warn"].append(msg)

    def getPrefix(self, prefix, filterType = [], limit=False):
        res = []
        filterFound = []
        pref = prefix.strip().lower()
        count = 0
        for key, value in self.db.iterator(prefix=pref.encode()):
            count += 1
            if len(filterType) > 0 and len(filterType) == len(filterFound):
                return res
            if limit and count > limit:
                return res
            try:
                data = json.loads(value.decode())
                if (len(filterType) > 0):
                    t = data["type"]
                    if t in filterType:
                        if not t in filterFound:
                            filterFound.append(t)
                            res.append(data)
                else:
                    res.append(data)
            except:
                print("Invalid DB entry (no JSON)")
        return res


    def getDomain(self, domain, filterType=[], limit=False):
        return self.getPrefix(domain.strip() + "!", filterType, limit)
