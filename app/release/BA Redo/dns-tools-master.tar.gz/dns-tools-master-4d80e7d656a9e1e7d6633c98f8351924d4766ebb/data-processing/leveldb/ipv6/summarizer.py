import ujson as json
import sys
import os

if __name__ == "__main__":
    res = {
        "process_fail": 0,
        "total": 0,
        "not_capable": 0,
        "not_investigated": 0,
        "capable": 0,
        "perfect": 0,
        "fixable": 0,
        "fixable_vague": 0,
        "ns_only_fault": 0,
	    "ns_only_fault_fixable": 0,
        "dom_only_fault": 0,
	    "dom_only_fault_fixable": 0,
        "stars": {
            "0.0": 0,
            "0.5": 0,
            "1.0": 0,
            "1.5": 0,
            "2.0": 0,
            "2.5": 0,
            "3.0": 0,
            "3.5": 0,
            "4.0": 0,
            "4.5": 0,
            "5.0": 0
        },
        "max_points": {

        },
        "points": {

        },
        "details": {
            "root": {
                "root": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "www": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "ns": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "mx": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                }
            },
            "www": {
                "root": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "www": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "ns": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "mx": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                }
            },
            "ns": {
                "root": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "www": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "ns": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "mx": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                }
            },
            "mx": {
                "root": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "www": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "ns": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                },
                "mx": {
                    "capable": 0,
                    "fixable": 0,
                    "fixable_vague": 0,
                    "problem": 0
                }
            }
        }
    }

    for line in sys.stdin:
        res["total"] += 1
        try:
            data = json.loads(line.strip())
            g = data["zgradenum"]
            mp = str(data["max_points"]).zfill(3)
            p = str(data["points"]).zfill(3)
            s = float(data["zstars"])
            summary = data["summary"]
            zAnalysis = data["zAnalysis"]["state"]
            if not summary["root"]["v4ready"]:
                res["not_investigated"] += 1

            # Details
            cats = ["root", "www", "ns", "mx"]
            for basecat in cats:
                if zAnalysis["state"][basecat]["fixable"]:
                    res["details"][basecat][basecat]["fixable"] += 1
                if zAnalysis["state"][basecat]["problem"]:
                    res["details"][basecat][basecat]["problem"] += 1
                if zAnalysis["state"][basecat]["fixable_vague"]:
                    res["details"][basecat][basecat]["fixable_vague"] += 1
                if zAnalysis["state"][basecat]["v6"]:
                    res["details"][basecat][basecat]["capable"] += 1
                    for subcat in cats:
                        if subcat != basecat:
                            if zAnalysis["state"][subcat]["v6"]:
                                res["details"][basecat][subcat]["capable"] += 1
                            if zAnalysis["state"][subcat]["problem"]:
                                res["details"][basecat][subcat]["problem"] += 1
                            if zAnalysis["state"][subcat]["fixable"]:
                                res["details"][basecat][subcat]["fixable"] += 1
                            if zAnalysis["state"][subcat]["fixable_vague"]:
                                res["details"][basecat][subcat]["fixable_vague"] += 1



            # Rating
            if p in res["points"]:
                res["points"][p] += 1
            else:
                res["points"][p] = 1
            if mp in res["max_points"]:
                res["max_points"][mp] += 1
            else:
                res["max_points"][mp] = 1
            res["stars"][str(s)] += 1
            if g == 1:
                res["perfect"] += 1
            elif g == 2:
                res["capable"] += 1
            else:
                res["not_capable"] += 1
                a = data["zAnalysis"]
                if a == False:
                    continue

                if a["fixable"]:
                    res["fixable"] += 1
                if a["fixable_vague"]:
                    res["fixable_vague"] += 1
                if a["state"]["ns"]["problem"]:
                    root = a["state"]["root"]["problem"]
                    www = a["state"]["www"]["problem"]
                    mx = a["state"]["mx"]["problem"]
                    if not (mx or root or www):
                        res["ns_only_fault"] += 1
                        if a["fixable"]:
    	                    res["ns_only_fault_fixable"] += 1
                else:
                    res["dom_only_fault"] += 1
                    if a["fixable"]:
                        res["dom_only_fault_fixable"] += 1


        except KeyError as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)
            print("KeyError: " + e.__str__())
            res["process_fail"] += 1
        except:
            print((sys.exc_info()[0]).__str__())
            res["process_fail"] += 1

    print(json.dumps(res, 
        sort_keys=True,
        indent=4))
