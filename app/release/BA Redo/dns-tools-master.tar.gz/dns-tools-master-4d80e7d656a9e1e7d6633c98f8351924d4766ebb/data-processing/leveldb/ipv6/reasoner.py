import json
import sys

class Reasoner:
    @staticmethod
    def reason(data, capableAsns = None):
        d = data["summary"]
        res = {
            # Network related issue(s)
            "network": False,
            # ASNs that are ipv6 ready (in general)
            "ipv6Asns": [],
            # Config related issue(s)
            "config": False,
            # Easy to fix? -> if config = True
            "fixable": False,
            "fixable_vague": False,
            # Reasons / logging
            "log": [],
            # Steps to fix issues
            "fixes": [],
            "state": {
                "root": {
                    "v6": False,
                    "network": False,
                    "config": False,
                    "fixable": False,
                    "fixable_vague": False,
                    "problem": True
                },
                "www": {
                    "v6": False,
                    "network": False,
                    "config": False,
                    "fixable": False,
                    "fixable_vague": False,
                    "problem": True
                },                
                "ns": {
                    "v6": False,
                    "network": False,
                    "config": False,
                    "fixable": False,
                    "fixable_vague": False,
                    "problem": True
                },
                "mx": {
                    "v6": False,
                    "network": False,
                    "config": False,
                    "fixable": False,
                    "fixable_vague": False,
                    "problem": True
                }
            }
        }
        partAsns = Reasoner.findV6asns(d)
        asns = {
            "root": [],
            "www": [],
            "ns": [],
            "mx": [],
            "all": partAsns[0]

        }
        if capableAsns != None:
            asns = capableAsns

        res["ipv6Asns"] = []
        res["asns"] = partAsns[1]
        for asn in res["asns"]:
            if asn in asns["all"]:
                res["ipv6Asns"].append(asn)

        if len(res["asns"]) == len(res["ipv6Asns"]):
            res["log"].append("All used ASNs are IPv6 ready")

        # Check root
        if not d["root"]["v6ready"]:
            # Why?
            if d["root"]["asn"] in asns["root"] or d["root"]["asn"] in asns["www"]:
                res["config"] = True
                res["state"]["root"]["config"] = True
                res["state"]["root"]["fixable"] = True
                res["state"]["root"]["fixable_vague"] = True
                res["log"].append("Domain is in IPv6-capable ASN (Provides other root or www subdomains using IPv6)")
                res["fixes"].append("Add AAAA Record for domain")
            else:
                res["network"] = True
                res["state"]["root"]["network"] = True
                res["log"].append("Domain seems to be in non IPv6-capable ASN (No other www subdomain or root known)")
                res["fixes"].append("Move Host to IPv6-capable ASN")
                if d["root"]["asn"] in asns["all"]:
                    res["state"]["root"]["fixable_vague"] = True
                    res["log"].append("Domain: ASN has no IPv6 support for root and subdomain, however, other services (MX / NS) use IPv6 in this ASN")    
        else:
            res["state"]["root"]["v6"] = True
            res["state"]["root"]["problem"] = False

        # Check www
        if not d["www"]["v6ready"]:
            # Why?
            if d["www"]["asn"] in asns["root"] or d["www"]["asn"] in asns["www"]:
                res["config"] = True
                res["state"]["www"]["config"] = True
                res["state"]["www"]["fixable"] = True
                res["state"]["www"]["fixable_vague"] = True
                res["log"].append("www is in IPv6-capable ASN (Provides other root or www subdomains using IPv6)")
                res["fixes"].append("Add AAAA Record for www")
            else:
                res["network"] = True
                res["state"]["www"]["network"] = True
                res["log"].append("www seems to be in non IPv6-capable ASN (No other www subdomain or root known)")
                res["fixes"].append("Move www Host to IPv6-capable ASN")
                if d["www"]["asn"] in asns["all"]:
                    res["state"]["www"]["fixable_vague"] = True
                    res["log"].append("www: ASN has no IPv6 support for root and www subdomain, however, other services (MX / NS) use IPv6 in this ASN")    
        else:
            res["state"]["www"]["v6"] = True
            res["state"]["www"]["problem"] = False
        # Check NS
        if d["ns"]["any6"]:
            res["state"]["ns"]["v6"] = True
            res["state"]["ns"]["problem"] = False
        else:
            # Check all NS if any is in capable ASN
            foundNs = False
            for ns in d["ns"]["results"]:
                if ns["asn"] in asns["ns"]:
                    foundNs = True
                    res["state"]["ns"]["config"] = True
                    res["state"]["ns"]["fixable"] = True
                    res["state"]["ns"]["fixable_vague"] = True
                    res["log"].append("Nameserver " + ns["name"] + " is in IPv6-capable ASN (Other NS entries with IPv6 support exist)")
                    res["fixes"].append("Add AAAA Record for Nameserver " + ns["name"])
                elif ns["asn"] in asns["all"]:
                    res["state"]["ns"]["fixable_vague"] = True
                    res["log"].append("Nameserver " + ns["name"] + " is in partially IPv6-capable ASN (Other non-NS services provided)")
            if not foundNs:
                res["state"]["ns"]["network"] = True
                res["log"].append("All nameservers are in non-Ipv6-capable ASNs")
                res["fixes"].append("Switch to Nameservers in an IPv6-capable ASN")

        # Check MX
        if d["mx"]["any6"]:
            res["state"]["mx"]["v6"] = True
            res["state"]["mx"]["problem"] = False
        else:
            # Check if MX entries are present
            if d["mx"]["num"] == 0:
                res["state"]["mx"]["problem"] = False
                res["log"].append("There are no MX entries")
                res["fixes"].append("Add MX records")                
            else:
                # Check all MX if any is in capable ASN
                foundMx = False
                for mx in d["mx"]["results"]:
                    if mx["asn"] in asns["mx"]:
                        foundMx = True
                        res["state"]["mx"]["config"] = True
                        res["state"]["mx"]["fixable"] = True
                        res["state"]["mx"]["fixable_vague"] = True
                        res["log"].append("MX " + mx["name"] + " is in IPv6-capable ASN (Other MX entries known in this ASN with IPv6)")
                        res["fixes"].append("Add AAAA Record for MX " + mx["name"])
                    elif mx["asn"] in asns["all"]:
                        res["state"]["mx"]["fixable_vague"] = True
                        res["log"].append("MX " + mx["name"] + " is in partially IPv6-capable ASN (Other non-MX services provided)")
                if not foundMx:
                    res["state"]["mx"]["network"] = True
                    res["log"].append("All MX are in non-Ipv6-capable ASNs")
                    res["fixes"].append("Switch to MX in an IPv6-capable ASN")

        fixables = 0
        fixables_vague = 0
        problems = 0
        for key in ["mx", "ns", "root", "www"]:
            if res["state"][key]["problem"]:
                problems += 1
            if res["state"][key]["fixable"]:
                fixables += 1
            if res["state"][key]["fixable_vague"]:
                fixables_vague += 1
        if fixables >= problems:
            res["fixable"] = True
        if fixables_vague >= problems:
            res["fixable_vague"] = True

        return res

    @staticmethod
    def findV6asns(d):
        l = []
        l2 = []
        asn = d["root"]["asn"]
        if not asn in l2:
            l2.append(asn)
        if d["root"]["v6ready"]:
            if not asn in l:
                l.append(asn)
        asn = d["www"]["asn"]
        if not asn in l2:
            l2.append(asn)
        if d["www"]["v6ready"]:
            if not asn in l:
                l.append(asn)
        for ns in d["ns"]["results"]:
            asn = ns["asn"]
            if ns["v6ready"]:
                if not asn in l:
                    l.append(asn)
            if not asn in l2:
                l2.append(asn)
        for mx in d["mx"]["results"]:
            asn = mx["asn"]
            if mx["v6ready"]:
                if not asn in l:
                    l.append(asn)
            if not asn in l2:
                l2.append(asn)
        return [l, l2]
