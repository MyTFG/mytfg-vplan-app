import json
import sys

if __name__ == "__main__":
    pos = 0
    num = 0
    print("ALEXARANK;CDF")
    for line in sys.stdin:
        pos += 1
        try:
            data = json.loads(line.strip())
            g = data["zgradenum"]           
            if g <= 2:
                num += 1
            print(str(pos) + ";" + str(num))
        except KeyError as ek:
            print(ek.__str__())
        except:
            print((sys.exc_info()[0]).__str__())
            res["process_fail"] += 1