import ujson as json
import sys

"""
Allows to extract all IPv6 capable ASNs from a given IPv6-capability scan
"""
asns = {
    "root": [],
    "www": [],
    "mx": [],
    "ns": [],
    "all": []
}
for line in sys.stdin:
    res = json.loads(line)
    try:
        for asn in res["zAnalysis"]["ipv6Asns"]:
            if asn != None and asn != -1:
                if not asn in asns["all"]:
                    asns["all"].append(asn)
        # Extract root
        if res["summary"]["root"]["v6ready"]:
            asn = res["summary"]["root"]["asn"]
            if asn != None and asn != -1:
                if not asn in asns["root"]:
                    asns["root"].append(asn)

        # Extract www
        if res["summary"]["www"]["v6ready"]:
            asn = res["summary"]["www"]["asn"]
            if asn != None and asn != -1:
                if not asn in asns["www"]:
                    asns["www"].append(asn)

        # Extract MX
        for mx in res["summary"]["mx"]["results"]:
            if mx["v6ready"]:
                asn = mx["asn"]
                if asn != None and asn != -1:
                    if not asn in asns["mx"]:
                        asns["mx"].append(asn)

        # Extract NS
        for ns in res["summary"]["ns"]["results"]:
            if ns["v6ready"]:
                asn = ns["asn"]
                if asn != None and asn != -1:
                    if not asn in asns["ns"]:
                        asns["ns"].append(asn)


        #for asn in asns:
        #    print(str(asn))
    except:
        # Nothing to do
        continue

print(json.dumps(asns))

