from analyzer import Ipv6Analyzer
import ujson as json
import plyvel
import sys
import time

if __name__ == "__main__":    
    cachesize = 256 * 1024 * 1024
    db = plyvel.DB(sys.argv[1], create_if_missing=False, lru_cache_size=cachesize)

    if len(sys.argv) >= 3:
        asnfile = sys.argv[2]
    else:
        asnfile = False

    if len(sys.argv) == 4:
        asnlist = sys.argv[3]
    else:
        asnlist = False

    analyzer = Ipv6Analyzer(db, asnfile, asnlist)
    for dom in sys.stdin:
        dom = dom.strip()
        res = analyzer.analyze(dom)
        print(json.dumps(res))
