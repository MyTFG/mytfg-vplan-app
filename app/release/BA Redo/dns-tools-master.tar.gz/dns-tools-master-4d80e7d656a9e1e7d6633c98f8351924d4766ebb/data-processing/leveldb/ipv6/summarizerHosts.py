import ujson as json
import sys
import os

if __name__ == "__main__":
    aspects = sys.argv[2:]
    with open(sys.argv[1], "r") as f:
        data = json.load(f)

    for aspect in aspects:
        res = {
            "fixableASN": 0,
            "fixableSubnet21": 0,
            "fixableHost": 0,
            "problem": 0,
            "v6ready": 0,
            "total": 0,
            "procASN": 0,
            "procSubnet": 0,
            "aspect": aspect
        }
        if aspect == "all":
            for dom, v in data.items():
                res["total"] += 1

                cats = {
                    "mx": {
                        "p": False,
                        "a": False,
                        "s": False,
                        "h": False
                    },
                    "ns": {
                        "p": False,
                        "a": False,
                        "s": False,
                        "h": False
                    },
                    "www": {
                        "p": False,
                        "a": False,
                        "s": False,
                        "h": False
                    },
                    "root": {
                        "p": False,
                        "a": False,
                        "s": False,
                        "h": False
                    }
                }

                for t in ["www", "ns", "mx", "root"]:
                    if not v[t]["v6ready"]:
                        if t == "mx":
                            cats[t]["p"] = v[t]["problem"]
                        else:
                            cats[t]["p"] = True

                    if v[t]["asnFixable"]:
                        cats[t]["a"] = True
                        if v[t]["subnetFixable"]:
                            cats[t]["s"] = True                        
                        if v[t]["hostFixable"]:
                            cats[t]["h"] = True
                p = False
                s = True
                h = True
                a = True
                for t in ["www", "ns", "mx", "root"]:
                    p = p or cats[t]["p"]
                    if cats[t]["p"]:
                        s = p and s and cats[t]["s"]
                        a = p and a and cats[t]["a"]
                        h = p and h and cats[t]["h"]
                if p:
                    res["problem"] += 1
                    if a:
                        res["fixableASN"] += 1
                    if s:
                        res["fixableSubnet21"] += 1
                    if h:
                        res["fixableHost"] += 1
                else:
                    res["v6ready"] += 1

        else:
            for dom, v in data.items():
                res["total"] += 1
                if not v[aspect]["v6ready"]:
                    res["problem"] += 1
                    if v[aspect]["asnFixable"]:
                        res["fixableASN"] += 1
                        if v[aspect]["subnetFixable"]:
                            res["fixableSubnet21"] += 1
                        if v[aspect]["hostFixable"]:
                            res["fixableHost"] += 1
                else:
                    res["v6ready"] += 1

        res["procASN"] = res["fixableASN"] / res["problem"]
        res["procSubnet"] = res["fixableSubnet21"] / res["problem"]

        print(json.dumps(res, indent=4))
