import ujson as json
import sys
import ipaddress

"""
Allows to extract all IPv6 capable IPv4 addresses / hosts from a given IPv6-capability scan
"""
hosts = {
    
}
for line in sys.stdin:
    res = json.loads(line)
    #try:              
    dom = res["domain"]  
    # Extract root and www
    for t in ["root", "www"]:
        if t == "root":
            name = dom
        else:
            name = "www." + dom

        if res["summary"][t]["v6ready"]:
            ip = res["summary"][t]["ipv4"]
            network = str(ipaddress.ip_network(ip + "/21", False))
            ip6 = res["summary"][t]["ipv6"]

            if network in hosts:
                if not t in hosts[network]["types"]:
                    hosts[network]["types"].append(t)
                hosts[network]["names"].append(name)
                hosts[network]["v4addresses"].append(ip)
                hosts[network]["v6addresses"].append(ip6)
            else:
                hosts[network] = {
                    "v4addresses": [ip],
                    "v6addresses": [ip6],
                    "names": [name],
                    "types": [t]
                }
    # MX and NS
    for t in ["mx", "ns"]:
        if res["summary"][t]["any6"]:
            for h in res["summary"][t]["results"]:
                if h["v6ready"]:
                    ip = h["ipv4"]
                    if len(ip) == 0:
                        continue
                    network = str(ipaddress.ip_network(ip + "/21", False))
                    ip6 = h["ipv6"]

                    if network in hosts:
                        if not t in hosts[network]["types"]:
                            hosts[network]["types"].append(t)
                        hosts[network]["names"].append(name)
                        hosts[network]["v4addresses"].append(ip)
                        hosts[network]["v6addresses"].append(ip6)
                    else:
                        hosts[network] = {
                            "v4addresses": [ip],
                            "v6addresses": [ip6],
                            "names": [name],
                            "types": [t]
                        }


print(json.dumps(hosts))

