import ujson as json
import sys

"""
Allows to extract all IPv6 capable IPv4 addresses / hosts from a given IPv6-capability scan
"""
hosts = {
    
}
for line in sys.stdin:
    res = json.loads(line)
    #try:              
    dom = res["domain"]  
    # Extract root and www
    for t in ["root", "www"]:
        if t == "root":
            name = dom
        else:
            name = "www." + dom
        if res["summary"][t]["v6ready"]:
            ip = res["summary"][t]["ipv4"]
            ip6 = res["summary"][t]["ipv6"]
            if ip in hosts:
                if not t in hosts[ip]["types"]:
                    hosts[ip]["names"].append(name)
                    hosts[ip]["types"].append(t)
            else:
                hosts[ip] = {
                    "ipv4": ip,
                    "ipv6": ip6,
                    "names": [name],
                    "types": [t]
                }
    # NS and MX
    for t in ["mx", "ns"]:
        if res["summary"][t]["any6"]:
            for r in res["summary"][t]["results"]:
                if r["v6ready"]:
                    ip = r["ipv4"]
                    ip6 = r["ipv6"]
                    name = r["name"]
                    if ip in hosts:
                        if not t in hosts[ip]["types"]:
                            hosts[ip]["names"].append(name)
                            hosts[ip]["types"].append(t)
                    else:
                        hosts[ip] = {
                            "ipv4": ip,
                            "ipv6": ip6,
                            "names": [name],
                            "types": [t]
                        }


print(json.dumps(hosts))

