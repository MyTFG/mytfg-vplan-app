from analyzer import Ipv6Analyzer
import json
import plyvel
import sys

class CLR:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

if __name__ == "__main__":    
    print("Loading DB")
    db = plyvel.DB(sys.argv[1], create_if_missing=False)
    if len(sys.argv) == 4:
        asnfile = sys.argv[2]
        dom = sys.argv[3]
    else:
        asnfile = False
        dom = sys.argv[2]

    analyzer = Ipv6Analyzer(db, asnfile)
    res = analyzer.analyze(dom)
    sys.exit(0)
    print(json.dumps(res, 
        sort_keys=True,
        indent=4, 
        separators=(',', ': ')))
    if (res["zgradenum"] == 1):
        print(CLR.OKGREEN + "Fully IPv6 compatible!" +  CLR.ENDC)
    elif (res["zgradenum"] == 2):
        print(CLR.WARNING + "IPv6 compatible - some aspects should be improved" +  CLR.ENDC)
    else:
        print(CLR.FAIL + "Not IPv6 compatible" +  CLR.ENDC)
