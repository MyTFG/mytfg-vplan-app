import plyvel
import ujson as json


class Analyzer():
    def __init__(self, db):
        self.db = db

    def getPrefix(self, prefix, filterType = [], limit=False):
        res = []
        filterFound = []
        pref = prefix.strip().lower()
        count = 0
        for key, value in self.db.iterator(prefix=pref.encode()):
            count += 1
            if len(filterType) > 0 and len(filterType) == len(filterFound):
                return res
            if limit and count > limit:
                return res
            try:
                data = json.loads(value.decode())
                if (len(filterType) > 0):
                    t = data["type"]
                    if t in filterType:
                        if not t in filterFound:
                            filterFound.append(t)
                            res.append(data)
                else:
                    res.append(data)
            except:
                print("Invalid DB entry (no JSON)")
        return res


    def getDomain(self, domain, filterType=[], limit=False):
        return self.getPrefix(domain.strip() + "!", filterType, limit)

    def filter(self, rlist, type, status="NOERROR"):
        res = []
        for data in rlist:
            # Check status
            if status == data["status"]:
                if status == "NOERROR":
                    # Check type
                    if data["type"] == type:
                        res.append(data)
                else:
                    # Other Status Message: No type!
                    res.append(data)
        return res