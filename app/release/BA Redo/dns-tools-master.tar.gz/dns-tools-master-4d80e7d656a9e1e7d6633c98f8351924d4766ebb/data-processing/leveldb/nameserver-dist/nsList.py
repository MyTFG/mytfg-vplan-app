#from analyzer import Ipv6Analyzer
import ujson as json
import plyvel
import sys
import time
from operator import itemgetter
from analyzer import Analyzer

def splitDom(name):
    return name.split(".")

def secondLvl(name):
    ls = splitDom(name)
    return ".".join(ls[-2:])


if __name__ == "__main__":    
    cachesize = 256 * 1024 * 1024
    db = plyvel.DB(sys.argv[1], create_if_missing=False, lru_cache_size=cachesize)

    a = Analyzer(db)
    t = "NS"

    res = {
        "ns": {

        },
        "sld": {

        },
        "zBiggest": {

        }
    }

    for dom in sys.stdin:
        # get        
        dom = dom.strip() 
        #print(dom)
        entries = a.getDomain(dom, [t], 100)

        nameservers = []

        for en in entries:
            for record in en["data"]["answers"]:
                if record["type"] == t:
                    nameservers.append(record["answer"])

        nameservers = list(set(nameservers))

        for ns in nameservers:
            # Extract A / AAAA
            details = a.getDomain(ns, ["A", "AAAA"], 10)
            nsA = a.filter(details, "A")
            nsAAAA = a.filter(details, "AAAA")

            v4 = False
            for x in nsA:
                for r in x["data"]["answers"]:
                    if r["type"] == "A":
                        v4 = True
            
            v6 = False
            for x in nsAAAA:
                for r in x["data"]["answers"]:
                    if r["type"] == "AAAA":
                        v6 = True

            if ns in res["ns"]:
                # Extend existing entry
                if res["ns"][ns]["domains"][-1] != dom:
                    res["ns"][ns]["domains"].append(dom)
                res["ns"][ns]["v4"] = res["ns"][ns]["v4"] or v4
                res["ns"][ns]["v6"] = res["ns"][ns]["v6"] or v6
                res["ns"][ns]["v6all"] = res["ns"][ns]["v6"] and v6
                res["ns"][ns]["v4all"] = res["ns"][ns]["v4"] and v6
            else:
                # Create new entry
                e = {
                    "domains": [dom],
                    "v4": v4,
                    "v6": v6,
                    "v4all": v4,
                    "v6all": v6
                }
                res["ns"][ns] = e

            # 2nd Level Dom
            sld = secondLvl(ns)
            if sld in res["sld"]:
                # Extend
                if not ns in res["sld"][sld]["ns"]:
                    res["sld"][sld]["ns"].append(ns)
                if not res["sld"][sld]["dom"][-1] == dom:
                    res["sld"][sld]["dom"].append(dom)
                res["sld"][sld]["v4"] = res["sld"][sld]["v4"] or v4
                res["sld"][sld]["v6"] = res["sld"][sld]["v6"] or v6
                res["sld"][sld]["v6all"] = res["sld"][sld]["v6all"] and v6
                res["sld"][sld]["v4all"] = res["sld"][sld]["v4all"] and v4
            else:
                # Create
                e = {
                    "ns": [ns],
                    "dom": [dom],
                    "v4": v4,
                    "v6": v6,
                    "v4all": v4,
                    "v6all": v6,
                }
                res["sld"][sld] = e

    # Extract biggest SLDs
    biggestTop = sorted(res["sld"], key=lambda x: (0 - len(res["sld"][x]['dom'])))
    #if len(biggest) > 10:
    #    biggestTop = biggest[:10]
    #else:
    #    biggestTop = biggest

    biggest = []
    for b in biggestTop:
        e = res["sld"][b]
        e["sld"] = b
        e["num"] = len(e["dom"])
        biggest.append(e)


    res["zBiggest"] = biggest

    print(json.dumps(res))
