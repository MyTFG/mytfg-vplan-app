import ujson as json
import sys

def prettyprint(p):
    #print(p)
    #return
    ls = p.split(" | ")
    lens = [4, 30, 5, 5, 6, 6, 10, 5]
    default = 5
    parts = []
    for i, x in enumerate(ls):
        pad = default
        if i < len(lens):
            pad = lens[i]
        parts.append(x.ljust(pad))
    print(" | ".join(parts))

if __name__ == "__main__":
    try:
        with open(sys.argv[1], "r") as f:
            data = json.load(f)

        if len(sys.argv) > 2:
            out = data["zBiggest"][int(sys.argv[2])]
            out["zSld"] = out["sld"]
            out["zV6"] = out["v6"]
            out["zV4"] = out["v4"]
            out["zDomCount"] = out["num"]
            out["zNSCount"] = len(out["ns"])
            if len(sys.argv) > 3:
                out["ns"] = False
                out["dom"] = False

            print(json.dumps(out, indent=4))
        else:
            biggest = data["zBiggest"]
            prettyprint("POS | Name (SLD) | V6 | V4 | V6 All | V4 All | DNUM | NSNUM")
            print("------------------------------------------------")
            for k, b in enumerate(biggest):
                nscount = len(b["ns"])
                ln = str(k) + " | " + b["sld"] + " | " + str(b["v6"]) + " | " + str(b["v4"]) + " | " + str(b["v6all"]) + " | " + str(b["v4all"]) + " | " + str(b["num"]) + " | " + str(nscount)
                prettyprint(ln)
    except Exception:
        print("DONE")