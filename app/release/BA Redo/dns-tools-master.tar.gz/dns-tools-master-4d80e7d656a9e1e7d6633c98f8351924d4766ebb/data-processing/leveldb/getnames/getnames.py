import plyvel
import sys
import ipaddress

#from classes.argparser import ArgParser
#from tools.multiusage import MultiUsage

def ipob2str(ipob, leng=32):
    strlen = str(leng+2)
    return format(int(ipob), '#0'+strlen+'b')

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=False)
    for i in range(2, len(sys.argv)):
        req = sys.argv[i] 
        networkstr = req
        # Create IPNetwork Object
        try:
            network = ipaddress.ip_network(networkstr, False)
        except AddressValueError:
            print("Invalid IP Address")
        except NetmaskValueError:
            print("Invalid Netmask")
        # Get "IP" Address
        ip = network.network_address

        # Prefixlength of IP
        prefixlen = network.prefixlen
        # Max IP length (32 or 128)
        maxlen = network.max_prefixlen
        # Bits to shift
        shiftlen = maxlen - prefixlen

        ipob = ipaddress.ip_address(ip)
        ipbits=bin(int(ipob))
        ipprefix = int(ipob) >> shiftlen
        #prefix = str(bin(ipprefix))
        prefix = ipob2str(ipprefix, prefixlen)
        print(prefix)

        #print("Names for " + networkstr)
        #print("Byte representation: " + str(str(prefix).encode()))
        for key, value in db.iterator(prefix=prefix.encode()):
            realip = int((key.decode().split("!"))[0], 0)
            realip = ipaddress.ip_address(realip)
            realip = str(realip)
            print(value.decode() + " " + realip)
            #print(key.decode())

    db.close()
