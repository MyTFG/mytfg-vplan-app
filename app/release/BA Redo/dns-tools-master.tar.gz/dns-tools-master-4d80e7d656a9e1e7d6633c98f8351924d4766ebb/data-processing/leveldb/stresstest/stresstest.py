import plyvel
import sys
import random
import socket
import struct
import time
import datetime

def zfill(part):
    return part.zfill(3)

def padip(ip):
    iplist = ip.split(".")
    iplist = map(zfill, iplist)
    return ".".join(iplist)

def ip2int(addr):                       
    return struct.unpack("!I", socket.inet_aton(addr))[0]


def int2ip(addr):                                                               
    return socket.inet_ntoa(hex(ip)[2:].zfill(8).decode('hex'))

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Not enough arguments. Usage:")
        print("stresstest.py LEVELDB STRESSTESTSOURCE1 [STRESSTESTSOURCE2 [...]]")
        print("  LEVELDB:           LevelDB data dir")
        print("  STRESSTESTSOURCE:  Path to a file containing IPs to query")
        sys.exit()

    hline = "==============================================="

    # Open DB
    timeGlobalStart = time.time()
    print("[ INFO ] Loading DB")
    db = plyvel.DB(sys.argv[1], create_if_missing=False)
    print("[ INFO ] Loaded DB")
    print("[ STAT ] Loading took " + str(time.time() - timeGlobalStart))
    
    # Reset time after DB was loaded
    timeGlobalStart = time.time()
    globalResults = 0
    globalQueries = 0
    fileNum = 0

    # Loop all stresstests
    for infile in sys.argv[2:]:
        fileNum += 1
        print(hline)
        now = datetime.datetime.now()
        print("[ INFO ] Starting stresstest " + infile)
        print("[ INFO ] Starting time: " + str(now))
        # Start time
        timeStart = time.time()
        resultCount = 0
        queryCount = 0
        timeFound = 0
        timeNFound = 0
        numNFound = 0
        queryTimes = []
        # Query all IPs
        with open(infile) as fp:
            for line in fp:
                qtimeS = time.time()
                found = False
                line = line.strip()
                queryCount += 1
                for key, value in db.iterator(prefix=line.encode()):
                    found = True
                    resultCount += 1
                qtimeE = time.time() - qtimeS
                if found:
                    timeFound += qtimeE
                else:
                    numNFound += 1
                    timeNFound += qtimeE
                queryTimes.append(time.time() - timeStart)

        now = datetime.datetime.now()
        print("[ INFO ] Stresstest done")
        print("[ INFO ] Finish time: " + str(now))
        print("[ STAT ] Results: " + str(resultCount))
        print("[ STAT ] Queried IPs: " + str(queryCount))
        print("[ STAT ] TotalResults: " + str(resultCount))
        print("[ STAT ] Needed time: " + str(time.time() - timeStart))
        print("[ STAT ] Time for existent key queries: " + str(timeFound))
        print("[ STAT ] Time for non-existent key queries: " + str(timeNFound))
        print("[ STAT ] Number of non-existent keys: " + str(numNFound))
        print("[ INFO ] CSV File: level-stresstest-" + str(fileNum) + ".csv")
        with open("level-stresstest-" + str(fileNum) + ".csv", "w") as csv:
            csv.write("QUERY;SECONDS\n")
            for i, t in enumerate(queryTimes):
                csv.write(str(i) + ";" + str(t) + "\n")

        globalResults += resultCount
        globalQueries += queryCount

    # End time
    timeGlobalEnd = time.time()
    # FINISH
    print(hline)
    print("[ INFO ] All tests done")
    print("[ STAT ] Total time: " + str(time.time() - timeGlobalStart))
    print("[ STAT ] Total Results: " + str(globalResults))
    print("[ STAT ] Total Queries: " + str(globalQueries))
