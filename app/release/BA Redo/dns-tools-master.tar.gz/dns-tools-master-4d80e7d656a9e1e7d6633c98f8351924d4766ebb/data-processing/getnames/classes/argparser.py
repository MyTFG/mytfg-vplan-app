import argparse

class ArgParser(object):
    def __init__(self):
        self.progname = "ADNS"
        self.versionstr = "0.2"
        self.progversion = "{0} {1}".format(self.progname, self.versionstr)
        self.parser = argparse.ArgumentParser(description="Perform asynchronous DNS requests.", prog=self.progname)
        #self.query()
        self.type()
        self.statistics()
        self.interval()
        #self.input()
        self.nameservers()
        self.timeout()
        self.tries()
        #self.maxqueries()
        self.calls()
        self.rotate()
        self.version()
        self.errorcorrection()
        self.library()
        self.format()

    def getParser(self):
        return self.parser

    def query(self):
        p = self.parser
        p.add_argument("--query", "-q", metavar="QUERY", action="append", 
            help="Hostname/IP to query (Multi-Option)")

    def type(self):
        p = self.parser
        p.add_argument("--type", "-t", action="append", default=[], 
            choices=["A", "AAAA", "CNAME", "MX", "NAPTR", "NS", "PTR", "SOA", "SRV", "TXT", "ALL"], 
            help="Query-Types (Record-Types). Default: A")

    def format(self):
        p = self.parser
        p.add_argument("--format", "-fm", action="store", default="json", 
            choices=["json", "raw"], 
            help="Output format. Default: JSON")
    
    def statistics(self):
        p = self.parser
        p.add_argument("--statistics", action="store",
            help="File for statistics (appended). Default: None")

    def interval(self):
        p = self.parser
        p.add_argument("--interval", metavar="SEC", 
            action="store", 
            default="0.0001", 
            help="Number of Seconds (float) to wait between each query (Default: 0.0001s)",
            type=float)

    def library(self):
        p = self.parser
        p.add_argument("--lib", action="store", default="twisted", 
            choices=["pycares", "twisted"], 
            help="Library to use. Default: twisted")

    def input(self):
        p = self.parser
        p.add_argument("--inputfile", "-i", action="store", 
            metavar="FILE",
            type=open, 
            help="Input file containing a list of domains")

    def nameservers(self):
        p = self.parser
        p.add_argument("--nameserver", "-ns", metavar="NS",
            help="Nameservers to use (Multi-Option)",
            action="append")

    def timeout(self):
        p = self.parser
        p.add_argument("--timeout", metavar="SEC", 
            action="store", 
            default="5", 
            help="Number of Seconds (float) to wait for each Nameserver (Default: 5s)",
            type=float)

    def tries(self):
        p = self.parser
        p.add_argument("--tries", metavar="NUM", 
            action="store", 
            default="1", 
            help="Number of retries per Nameserver (Default 1)",
            type=int)


    def version(self):
        p = self.parser
        p.add_argument("--version", action="version", version=self.progversion)

    def maxqueries(self):
        p = self.parser
        p.add_argument("--maxqueries", "-mq", metavar="NUM", 
            action="store", 
            default="-1", 
            help="Max. number of queries to execute (For lists as input)",
            type=int)

    def calls(self):
        p = self.parser
        p.add_argument("--calls", metavar="NUM",
            action="store",
            default="0",
            help="Max. number of concurrent queries (Default: Auto-adapt)",
            type=int)

    def rotate(self):
        p = self.parser
        p.add_argument("--rotate", 
                action="store_true",
                help="Set, if nameserver should be rotated")

    def errorcorrection(self):
        p = self.parser
        p.add_argument("--ec", 
                action="store_true",
                help="Set, if ADNS should retry on Timeouts due to Server overload (ADNS+)")
        