from radix import Radix
import sys
import ujson as json
import time
import datetime
import socket
import _pickle as cPickle

from memory import *
from classes.argparser import ArgParser
from classes.log import Log
from tools.multiusage import MultiUsage
from tools.stresstest import StressTest

def zfill(part):
    return part.zfill(3)

def zrem(part):
    return part.lstrip("0")

def emptyToZ(part):
    if part == "":
        return "0"
    else:
        return part

def padip(ip):
    iplist = ip.split(".")
    iplist = map(zfill, iplist)
    return ".".join(iplist)

def unpad(ip):
    iplist = ip.split(".")
    iplist = map(zrem, iplist)
    iplist = map(emptyToZ, iplist)
    return ".".join(iplist)

if __name__ == "__main__":
    rtree = Radix()
    i = 0
    log = Log(True)
    loaded = False

    if len(sys.argv) > 1:
        treefile = sys.argv[1]
    else:
        treefile = False


    timeGlobalStart = time.time()
    globalResults = 0
    globalQueries = 0
    if os.path.isfile(treefile):
        log.info("Loading tree from file: " + treefile)
        log.stat("Memory: " + str(memoryMb()) + "MB")
        loaded = True
        rtree = cPickle.load(open(treefile, 'rb'))
    else:
        log.info("Start building tree")
        log.stat("Memory: " + str(memoryMb()) + "MB")

        for line in sys.stdin:
            line = line.strip()
            i+=1
            if (line == ""):
                continue
            try:
                x = json.loads(line)
            except ValueError as e:
                log.error(str(i) + ": " + line)

            status = x["status"]
            if (status != "NOERROR"):
                continue

            answers = x["data"]["answers"]

            # Gather all A / (AAAA) records in answer section
            for record in answers:
                rtype = record["type"]
                if (rtype == "A"):
                    # or rtype == "AAAA"):
                    # Extract IP and name, map ip->name
                    ip = unpad(record["answer"])
                    # log.info(ip)
                    name = record["name"]
                    rnode = rtree.add(ip)
                    # IP already existing?
                    if ("names" in rnode.data):
                        # Yes: Append to results
                        rnode.data["names"].append(name)
                    else:
                        # No: Create new result list
                        rnode.data["names"] = [name]
            if i % 100000 == 0:
                log.info("Done: " + str(i))

    # TODO: Start counting or save mapping
    #mu = MultiUsage()
    #mu.start(rtree, None)
    log.info("Tree complete.")
    log.stat("Needed time: " + str(time.time() - timeGlobalStart))
    log.stat("Memory: " + str(memoryMb()) + "MB")
    log.hline()

    timeGlobalStart = time.time()

    stresstest = StressTest()
    stresstest.start(rtree, sys.argv)

    if not loaded:
        if treefile != False:
            log.info("Saving tree to " + treefile)
            start = time.time()
            cPickle.dump(rtree, open(treefile, 'wb'))
            end = time.time()
            log.stat("Saving took: " + str(end - start))

    # PRINT REVERSE MAPPINGS (JSON)
    """for rnode in rtree:
        data = {
            "ip": rnode.network,
            "names": rnode.data["names"]
        }
        print(json.dumps(data))
    """
