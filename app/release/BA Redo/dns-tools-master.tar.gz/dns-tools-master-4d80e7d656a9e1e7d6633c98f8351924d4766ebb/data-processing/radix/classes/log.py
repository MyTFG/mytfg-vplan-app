class Log(object):
    def __init__(self, enabled):
        self.enabled = enabled        

    def error(self, msg):
        if self.enabled:
            print("[ ERR  ] " + msg)

    def info(self, msg):
        if self.enabled:
            print("[ INFO ] " + msg)

    def stat(self, msg):
        if self.enabled:
            print("[ STAT ] " + msg)

    def hline(self):
        if self.enabled:
            print("===============================================")