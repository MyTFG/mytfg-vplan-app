from abc import ABC, abstractmethod

class RadixAnalysis(ABC):
    @abstractmethod
    def start(self, tree, args):
        return
