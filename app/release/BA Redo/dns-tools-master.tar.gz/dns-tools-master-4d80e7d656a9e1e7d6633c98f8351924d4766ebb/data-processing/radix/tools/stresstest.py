"""
Performs a stresstest on data stored in the Radix Tree.
For every IP the amount of corresponding domains is calculated.
The output is a mapping of Occurance-Amounts to a number of IP-addresses.
"""
from tools.analysis import RadixAnalysis
from classes.log import Log
import collections
import time
import datetime

def zrem(part):
    return part.lstrip("0")

def emptyToZ(part):
    if part == "":
        return "0"
    else:
        return part

def unpad(ip):
    iplist = ip.split(".")
    iplist = map(zrem, iplist)
    iplist = map(emptyToZ, iplist)
    return ".".join(iplist)


class StressTest(RadixAnalysis):
    def start(self, tree, args):
        timeGlobalStart = time.time()
        globalResults = 0
        globalQueries = 0
        log = Log(True)

        for infile in args[2:]:
            log.hline()
            now = datetime.datetime.now()
            log.info("Starting stresstest " + infile)
            log.info("Starting time: " + str(now))
            # Start time
            timeStart = time.time() 
            resultCount = 0
            queryCount = 0
            # Query all IPs
            with open(infile) as fp:
                for line in fp:
                    line = line.strip()
                    queryCount += 1
                    rnode = tree.search_exact(unpad(line))
                    if rnode != None:
                        resultCount += len(rnode.data["names"])

            now = datetime.datetime.now()
            log.info("Stresstest done")
            log.info("Finish time: " + str(now))
            log.stat("Results: " + str(resultCount))
            log.stat("Queried IPs: " + str(queryCount))
            log.stat("TotalResults: " + str(resultCount))
            log.stat("Needed time: " + str(time.time() - timeStart))

            globalResults += resultCount
            globalQueries += queryCount

        # End time
        timeGlobalEnd = time.time()
        # FINISH
        log.hline()
        log.info("All tests done")
        log.stat("Total time: " + str(time.time() - timeGlobalStart))
        log.stat("Total Results: " + str(globalResults))
        log.stat("Total Queries: " + str(globalQueries))
