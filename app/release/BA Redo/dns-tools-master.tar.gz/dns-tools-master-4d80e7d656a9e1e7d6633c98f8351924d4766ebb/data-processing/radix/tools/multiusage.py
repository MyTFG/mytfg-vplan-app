"""
Performs an analysis on multiusage of IP-Adresses.
For every IP the amount of corresponding domains is calculated.
The output is a mapping of Occurance-Amounts to a number of IP-addresses.
"""
from tools.analysis import RadixAnalysis
import collections


class MultiUsage(RadixAnalysis):
    def start(self, tree, args):
        results = {}
        for rnode in tree:
            names = rnode.data["names"]
            nc = len(names)
            ncstr = str(nc)
            if nc in results:
                results[nc]["amount"] += 1
                results[nc]["names"] += names
                results[nc]["addresses"] += [rnode.network]
            else:
                results[nc] = {
                    "addresses": [rnode.network],
                    "amount": 1,
                    "names": names
                }

        print("Domains;IPs")
        results = collections.OrderedDict(sorted(results.items()))
        for nc in results:
            num = results[nc]["amount"]
            print(str(nc) + ";" + str(num))
            """
            out = str(nc).rjust(8, " ") + " : " + str(num).rjust(8, " ")
            if num <= 7:
                out += "   (" + results[nc]["addresses"].__str__() + ")"
            print(out)"""