import plyvel
import sys
import collections

if __name__ == "__main__":
    db = plyvel.DB(sys.argv[1], create_if_missing=False)
    results = {}
    lastip = None
    count = 0
    for key, value in db:
        # Extract IP (Before "!")
        ip = key.decode().split("!")
        ip = ip[0]
        if ip == lastip:
            count += 1
        elif lastip != None:
            # Store last IP count
            if count in results:
                results[count]["amount"] += 1
            else:
                results[count] = {
                    "amount": 1
                }
            lastip = ip
            count = 1
        else:
            lastip = ip
            count = 1

    # Save last counted IP
    if lastip != None:
        if count in results:
            results[count]["amount"] += 1
        else:
            results[count] = {
                "amount": 1
            }


    print("Domains;IPs")
    results = collections.OrderedDict(sorted(results.items()))
    for nc in results:
        num = results[nc]["amount"]
        print(str(nc) + ";" + str(num))
        """
        out = str(nc).rjust(8, " ") + " : " + str(num).rjust(8, " ")
        if num <= 7:
            out += "   (" + results[nc]["addresses"].__str__() + ")"
        print(out)"""
    # Close DB
    db.close()

