import _pickle as cPickle
import socket
import struct
import time
import ipaddress

class Dictmap:
    def __init__(self, args):
        #self.map = {}
        #self.shift = 32 - args.keynum
        self.debug = args.debug
        self.modified = False
        #self.keynum = args.keynum
        #self.maxsize = (2**args.keynum) + 1
        # 2^32 ip addresses
        self.maxIpCount = 2**32
        #self.mask = ~(((~0) >> self.shift) << self.shift)
        # Mapfile
        self.mapfile = args.mapfile
        #self.printd("Shift: " + str(self.shift) + " to reach " + str(self.keynum) + " bit keys.")
        #self.printd("Mask: " + str(bin(self.mask)))
        #self.printd("Size: " + str(self.maxsize))
        #self.printd("SubSize: " + str(self.mask))
        # Load?
        if args.load:
            self.loadDict()
        else:
            self.map = {}


    def loadDict(self):
        self.printd("Loading Dict from File...")
        self.map = cPickle.load(open(self.mapfile, 'rb'))
        self.printd("Loaded Dict from File")

    def save(self):
        if not self.modified:
            return False
        self.printd("Saving Dict to File...")
        cPickle.dump(self.map, open(self.mapfile, 'wb'))
        self.printd("Saved Dict to File")

    """
    Add an IP->domainname mapping to the map

    Returns True iff entry was added, False if existing entry already found
    """
    def put(self, ip, name):
        if ip in self.map:
            ls = self.map[ip]
            ls.append(name)
            self.map[ip] = ls
            self.modified = True
            return True
        self.map[ip] = [name]
        self.modified = True
        return True


    """
    Get the domain name linked to the given IP.
    if no entry is found, default is returned. 
    If default == None, the given IP is returned instead.
    """
    def get(self, ip, default = None):
        if default == None:
            default = ip
        return self.map.get(ip, default)

    def hashPos(self, pos):
        # TODO: Use real hash function?! -> No
        return pos

    def ipToInt(self, ip):
        #return int(ipaddress.ip_address(ip))
        return struct.unpack("!I", socket.inet_aton(ip))[0] 

    def printd(self, val):
        if self.debug:
            print(val)

