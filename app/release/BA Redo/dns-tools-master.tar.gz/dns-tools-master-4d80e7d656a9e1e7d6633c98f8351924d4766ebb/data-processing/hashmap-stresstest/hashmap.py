import _pickle as cPickle
import socket
import struct
import time
import ipaddress

class Hashmap:
    def __init__(self, args):
        self.map = []
        self.shift = 32 - args.keynum
        self.debug = args.debug
        self.keynum = args.keynum
        self.maxsize = (2**args.keynum) + 1
        # 2^32 ip addresses
        self.maxIpCount = 2**32
        self.mask = ~(((~0) >> self.shift) << self.shift)
        # Mapfile
        self.mapfile = args.mapfile
        self.printd("Shift: " + str(self.shift) + " to reach " + str(self.keynum) + " bit keys.")
        self.printd("Mask: " + str(bin(self.mask)))
        self.printd("Size: " + str(self.maxsize))
        self.printd("SubSize: " + str(self.mask))
        # Load?
        if args.load:
            self.loadMap()
        else:
            self.map = [None] * self.maxsize


    def loadMap(self):
        self.printd("Loading Map from File...")
        self.map = cPickle.load(open(self.mapfile, 'rb'))
        self.printd("Loaded Map from File")

    def save(self):
        self.printd("Saving Map to File...")
        cPickle.dump(self.map, open(self.mapfile, 'wb'))
        self.printd("Saved Map to File")

    """
    Add an IP->domainname mapping to the map

    Returns True iff entry was added, False if existing entry already found
    """
    def put(self, ip, name):
        numip = self.ipToInt(ip)
        mainpos = numip >> self.shift
        subpos = numip & self.mask

        mainentry = self.map[mainpos]
        if mainentry != None:
            if mainentry[subpos] == None:
                self.map[mainpos][subpos] = name
                return True
        else:
            newentry = [None] * (self.mask + 1)
            newentry[subpos] = name
            self.map[mainpos] = newentry
            return True
        return False


    """
    Get the domain name linked to the given IP.
    if no entry is found, default is returned. 
    If default == None, the given IP is returned instead.
    """
    def get(self, ip, default = None):
        if default == None:
            default = ip
        numip = self.ipToInt(ip)
        mainpos = numip >> self.shift
        subpos = numip & self.mask
        mainentry = self.map[mainpos]
        if mainentry != None:
            finalentry = mainentry[subpos]
            if finalentry != None:
                return finalentry
        return default

    def hashPos(self, pos):
        # TODO: Use real hash function?! -> No
        return pos

    def ipToInt(self, ip):
        #return int(ipaddress.ip_address(ip))
        return struct.unpack("!I", socket.inet_aton(ip))[0] 

    def printd(self, val):
        if self.debug:
            print(val)

