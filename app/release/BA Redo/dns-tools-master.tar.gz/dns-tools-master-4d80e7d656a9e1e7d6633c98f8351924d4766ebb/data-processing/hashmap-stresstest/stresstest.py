import argparse
from hashmap import Hashmap
from dictmap import Dictmap
import ujson as json
#import yajl as json
import sys
import time
import os
from memory import *

def printd(val, args):
    if args.debug:
        print(val)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Hashmap Stresstest", prog="HASHMAP STRESSTEST")

    #parser.add_argument("--format", "-f", action="store", default="{0},{1}",  
    #    help="Output format. {0} represents the IP address, {1} is the domain name")
    #parser.add_argument("--keynum", "-n", action="store", default="28",
    #    type=int,
    #    help="Bitlength for keys. Use lower values when less IPs are stored")
    parser.add_argument("--file", "-f", action="append",
        default=[],
        help="File containing queries / IPs")
    parser.add_argument("--mapfile", "-mf", action="store",
        help="File to save the hashmap to.")
    parser.add_argument("--source", "-s", action="store",
        help="File containing the JSON results")
    parser.add_argument("--debug", "-d", action="store_true",
        help="Set to enable debug output")


    args = parser.parse_args()
    startt = time.time()

    print("[ STAT ] Memory: " + str(memoryMb()) + "MB")
    if os.path.isfile(args.mapfile):
        print("[ INFO ] Loading Hashmap from " + args.mapfile)
        args.load = True
        hashmap = Dictmap(args)
        print("[ INFO ] Loaded Hashmap")
        print("[ STAT ] Loading took: " + str(time.time() - startt))
    else:
        args.load = False
        print("[ INFO ] Creating Hashmap...")
        hashmap = Dictmap(args)
        putnum = 0
        num = 0
        with open(args.source, "r") as f:
            for line in f:
                try:
                    entry = json.loads(line)
                except ValueError:
                    continue
                #print(line)
                dom = entry["name"]
                for record in entry["data"]["answers"]:
                    if record["type"] == "A":
                        num += 1
                        if hashmap.put(record["answer"], dom):
                            #print("[  IP  ] " + record["answer"])
                            putnum += 1
        print("[ INFO ] Hashmap created")
        print("[ STAT ] Overall Records: " + str(num))
        print("[ STAT ] Distinct IPs: " + str(putnum))
        print("[ STAT ] Hashmap creation took: " + str(time.time() - startt))

    print("[ STAT ] Memory: " + str(memoryMb()) + "MB")
    print("[ INFO ] Starting Stresstest Part 2")
    for sf in args.file:
        print("[ INFO ] Starting Stresstest with file: " + sf)
        found = 0
        nFound = 0
        startt2 = time.time()
        with open(sf, "r") as f:
            for line in f:
                #print(line.strip())
                res = hashmap.get(line.strip(), False)
                #print("[ GET  ] " + str(res))
                if not res:
                    nFound += 1
                else:
                    found += len(res)
        print("[ INFO ] Stresstest complete for file " + sf)
        print("[ STAT ] Queries: " + str(nFound + found))
        print("[ STAT ] Results: " + str(found))
        print("[ STAT ] Non-existent: " + str(nFound))
        print("[ STAT ] Needed Time: " + str(time.time() - startt2))
    print("[ INFO ] All tests done")
    print("[ INFO ] Saving Hashmap to " + args.mapfile)
    savestart = time.time()
    hashmap.save()
    print("[ STAT ] Saving Took: " + str(time.time() - savestart))
    print("[ STAT ] Total Time: " + str(time.time() - startt))
