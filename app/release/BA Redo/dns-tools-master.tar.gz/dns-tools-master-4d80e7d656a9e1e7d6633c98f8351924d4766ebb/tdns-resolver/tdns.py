import argparse
import socket
import time
import json as json
import sys

from classes.argparser import ArgParser
from classes.iputils import IpUtils
from classes.adnsresolver import AdnsResolver
from classes.ipversion import IpVersion
from classes.multiproc import MultiProc

import twisted
from twisted.internet import reactor
from twisted.python import log

if __name__ == '__main__':
    done = 0
    failed = 0
    start = time.time()

    def raw_cb(result):
        for res in result:
            print(res.__str__())
            print("")
            print("")

    def json_cb(result):
        for res in result:
            output = json.dumps(res, default=lambda o: o.__dict__)
            print(output, flush=True)
            sys.stdout.flush()

    argparser = ArgParser()
    args = argparser.getParser().parse_args()

    # Get Querytypes
    types = args.type

    if (len(types) == 0):
        types = ["A"]

    options = {
        "types": types
    }

    if (args.format == "json"):
        callback = json_cb
    else:
        callback = raw_cb

    try:
        if args.threads == 1:
            args.queue = False
            #if args.log:
            #    log.startLogging(sys.stderr, setStdout=False)
            resolver = AdnsResolver(args)
            log.msg("Using Single Thread")
            resolver.runStdin(options, callback)
        else:
            mp = MultiProc(args, options, callback)
            mp.start()
        log.msg("Shutting down resolver")
    except KeyboardInterrupt:
        log.msg("TDNS received Interrupt")
        sys.exit(0)
