from enum import IntEnum

class RecordType(IntEnum):
    UNDEF =  0
    A =      1
    AAAA =   2
    CNAME =  3
    MX =     4
    NAPTR =  5
    NS =     6
    SOA =    7
    SRV =    8
    TXT =    9

    @staticmethod
    def fromString(str):
        return {
            "A": RecordType.A,
            "AAAA": RecordType.AAAA,
            "CNAME": RecordType.CNAME,
            "MX": RecordType.MX,
            "NAPTR": RecordType.NAPTR,
            "NS": RecordType.NS,
            "SOA": RecordType.SOA,
            "SRV": RecordType.SRV,
            "TXT": RecordType.TXT            
        }.get(str, RecordType.UNDEF)
