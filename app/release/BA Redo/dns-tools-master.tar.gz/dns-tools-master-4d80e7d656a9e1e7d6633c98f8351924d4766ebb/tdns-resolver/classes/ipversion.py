from enum import Enum

class IpVersion(Enum):
    UNDEF =  0
    IPv4  =  4
    IPv6  =  6