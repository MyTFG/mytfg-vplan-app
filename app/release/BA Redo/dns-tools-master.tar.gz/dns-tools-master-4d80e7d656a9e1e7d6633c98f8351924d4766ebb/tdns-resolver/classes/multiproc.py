import sys
import os
from multiprocessing import Queue
from queue import Empty
from multiprocessing import Process
import multiprocessing

import zmq

from twisted.python import log
from twisted.internet import reactor
from twisted.internet import task

from classes.adnsresolver import AdnsResolver

import time

class MultiProc:
    def __init__(self, args, options, callback):
        #multiprocessing.set_start_method('forkserver')
        self.queue = Queue()
        self.args = args
        self.closingQueue = Queue()
        self.procs = []
        args.queue = self.queue

        if args.zmq:
            context = zmq.Context()
            self.queue = context.socket(zmq.PUSH)
            if not args.zmqnofill:
                self.queue.bind("tcp://" + args.zmqaddr)
            #args.queue = True

        args.closingQueue = self.closingQueue
        self.count = 0
        self.running = 0
        self.interval = self.args.interval / (self.args.threads * 2)

        if args.log:
            log.startLogging(sys.stderr, setStdout=False)
        #else:
        #    log.startLogging(open('/dev/null', 'w'), setStdout=False)
        for i in range(args.threads):
            args.procnum = i
            self.procs.append(Process(target=self.initSubproc, args=(args, options)))

        log.msg("MULTIPROC: Using " + str(args.threads) + " processes")

    def start(self):
        self.startWorkers()
        if not self.args.zmqnofill:
            self.fillQueueBlock()
        self.wait()
        #if self.args.zmqnofill:
        #    self.startWorkers()
        #    self.closeQueue()
        #else:
            #self.sched = task.LoopingCall(self.fillQueue)
        #    self.sched.start(self.interval)
        #    reactor.run()

    def fillQueueBlock(self):
        for line in sys.stdin:
            line = line.strip()
            if self.args.zmq:
                self.queue.send_string(line)
            else:
                self.queue.put(line)

    def wait(self):
        log.msg("MULTIPROC: Waiting for processes to terminate")
        for p in self.procs:
            p.join()
        log.msg("MULTIPROC: TERMINATING - QUEUE CLOSES!")

    def fillQueue(self):
        line = sys.stdin.readline()
        if not line:
            self.closeQueue()
            return
        if self.args.zmq:
            self.queue.send_string(line)
        else:
            self.queue.put(line)

    def closeQueue(self):
        if not self.running:
            return
        self.running = 0
        self.sched.stop()
        if reactor.running:
            reactor.stop()
        #for p in self.procs:
        #    self.closingQueue.put("-")

        log.msg("MULTIPROC: Waiting for processes to terminate")
        for p in self.procs:
            p.join()

    def startWorkers(self):
        self.running = 0
        for p in self.procs:
            self.running += 1
            p.start()

    def startWorker(self):
        if self.running >= len(self.procs):
            log.msg("MULTIPROC: " + str(self.running) + " processes running - no more left")
            log.msg("MULTIPROC: Status:")
            log.msg("MULTIPROC:   " + str(len(self.procs)) + " processes")
            i = 1
            for p in self.procs:
                if p.poll() == None:
                    st = "Running"
                else:
                    st = "Stopped"
                log.msg("Process " + str(i) + ": " + st)
                i += 1
            return
        self.procs[self.running].start()
        log.msg("MULTIPROC: Started subprocess " + str(self.running))
        self.running += 1
        log.msg("MULTIPROC: Running subprocesses: " + str(self.running))

    def initSubproc(self, args, options):
        resolver = AdnsResolver(args)
        #time.sleep(args.procnum / 3.0)
        resolver.runStdin(options, None)
