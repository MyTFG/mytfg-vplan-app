import time
import json

class Statistics(object):
    def __init__(self, args):
        self.start = time.time()
        self.active = False
        self.file = None
        if (args.statistics):
            self.active = True
            self.file = args.statistics
        self.queries = 0
        self.noerror = 0
        self.failed = 0
        self.dnserror = 0

    def query(self, query, options):
        num = len(options["types"])
        self.queries += num
    
    def result(self, results):
        for result in results:
            if result.status == "NOERROR":
                self.noerror += 1
            elif result.status == "NXDOMAIN":
                self.dnserror += 1
            else:
                self.failed += 1

    def save(self):
        if self.active:
            end = time.time()
            diff = end - self.start
            res = {
                "time": diff,
                "queries": self.queries,
                "nxdomain": self.dnserror,
                "noerror": self.noerror,
                "failed": self.failed
            }
            resstr = json.dumps(res, default=lambda o: o.__dict__)
            with open(self.file, "a") as thefile:
                thefile.write(resstr + "\n")