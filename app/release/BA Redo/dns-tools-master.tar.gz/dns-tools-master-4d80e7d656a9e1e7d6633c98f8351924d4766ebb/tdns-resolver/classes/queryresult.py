from classes.dnsrecord import DnsRecord


class QueryResult(object):
    def __init__(self):
        self.name = ""
        self.status = "NOERROR"
        self.type = ""
        self.data = QueryData()
        self.protocol = "udp"
        self.log = ""
        self.flags = []

    def __repr__(self):
        return "QueryResult()"

    def __str__(self):
        str = ";; ANSWER SECTION: \n"
        for ans in self.data.answers:
            str += ans.__str__() + "\n"
        
        str += "\n;; AUTHORITY SECTION: \n"
        for ans in self.data.authorities:
            str += ans.__str__() + "\n"
            
        str += "\n;; ADDITIONAL SECTION: \n"
        for ans in self.data.additionals:
            str += ans.__str__() + "\n"
        
        return str

class QueryData(object):
    def __init__(self):
        self.answers = []
        self.authorities = []
        self.additionals = []
