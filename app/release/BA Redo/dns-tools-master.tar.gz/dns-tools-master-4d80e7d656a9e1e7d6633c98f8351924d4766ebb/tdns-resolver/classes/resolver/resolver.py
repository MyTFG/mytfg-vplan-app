class Resolver:
    def __init__(self, args):
        raise NotImplementedError() 

    def query(self, name, options, callback):
        raise NotImplementedError()