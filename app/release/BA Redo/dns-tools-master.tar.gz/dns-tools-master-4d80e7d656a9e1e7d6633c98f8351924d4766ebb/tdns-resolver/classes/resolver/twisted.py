from classes.resolver.resolver import Resolver
from classes.queryresult import QueryResult
from classes.dnsrecord import DnsRecord
from classes.recordtype import RecordType

import twisted
from twisted.internet import defer, reactor
from twisted.internet.task import react
from twisted.names import client, dns, error
from twisted.python import usage
from twisted.python.failure import Failure

import sys
import socket
import ujson as json
import os
import traceback
from twisted.python import log


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

class TwistedResolver(Resolver):
    # QUERY TYPES
    (A, NS, MD, MF, CNAME, SOA, MB, MG, MR, NULL, WKS, PTR, HINFO, MINFO, MX, TXT,
     RP, AFSDB) = range(1, 19)
    AAAA = 28
    SRV = 33
    NAPTR = 35
    A6 = 38
    DNAME = 39
    SPF = 99

    QUERY_TYPES = {
        A: 'A',
        NS: 'NS',
        MD: 'MD',
        MF: 'MF',
        CNAME: 'CNAME',
        SOA: 'SOA',
        MB: 'MB',
        MG: 'MG',
        MR: 'MR',
        NULL: 'NULL',
        WKS: 'WKS',
        PTR: 'PTR',
        HINFO: 'HINFO',
        MINFO: 'MINFO',
        MX: 'MX',
        TXT: 'TXT',
        RP: 'RP',
        AFSDB: 'AFSDB',
        # Special numbering...
        AAAA: 'AAAA',
        SRV: 'SRV',
        NAPTR: 'NAPTR',
        A6: 'A6',
        DNAME: 'DNAME',
        SPF: 'SPF'
    }

    def __init__(self, args):
        servers = []
        twistedargs = {}
        self.queries = []
        self.currentQueries = 0

        self.pid = "PID " + str(os.getpid())

        if (args.nameserver):
            for srv in args.nameserver:
                servers.append((srv, 53))
            twistedargs["servers"] = servers

        twistedargs["hosts"] = "alternate_host_file";

        self.timeouts = args.timeouts
        #print(args.timeouts)
        #for x in range(1, args.tries+1):
        #    self.timeouts.append(x * args.timeout)

        self.resolver = client.createResolver(**twistedargs)

        self.resolver.timeouts = self.timeouts

    def query(self, name, options, callback):
        types = options["types"]
        tasks = []
        flags = options["flags"]
        log.msg(self.pid + " Twisted trying to Query: " + name)

        for type in types:
            try:
                t = self.makeQuery(type, name, flags)
                if t != False:
                    tasks.append(t)
            except UnicodeError:
                log.err("TWISTED: Invalid domain passed: " + name)
                self.noQueryStarted(name, "ERROR: Invalid Query", callback, types, flags)
                return 0
            except Exception as e:
                log.err("TWISTED: Unknown Error Creating Query:")
                log.err("TWISTED: " + e.__str__())
                self.noQueryStarted(name, "ERROR: Unknown Error Creating Query", callback, types, flags)
                return 0

        log.msg(self.pid + " Twisted Query: " + name)
        try:
            d = defer.gatherResults(tasks, consumeErrors=True)
            self.currentQueries += 1
        except:
            self.noQueryStarted(name, "ERROR: Could not gather Results", callback, types, flags)
            return 0

        d.addCallback(callback)
        d.addErrback(self.dnsnameError, callback, name, types, flags)
        d.addErrback(self.timeoutError, callback, name, types, flags)
        d.addErrback(self.dnsserverError, callback, name, types, flags)
        d.addErrback(self.otherError, callback, name, types, flags)
        return 1

    def makeQuery(self, type, name, flags):
        r = self.resolver
        log.msg(self.pid + " makeQuery: " + name + " " + type)


        if type == "PTR":
            name = self.reverseNameFromIPAddress(name)
        query = twisted.names.dns.Query()
        query.name = twisted.names.dns.Name(name.encode())
        query.type = self.getType(type, True)
        query.cls = dns.IN
        

        return r.query(query, self.timeouts).addCallback(self.formatRecords, type, name, flags)

        if (type == "A"):
            t = r.lookupAddress(name, self.timeouts)
            log.msg(self.pid + " makeQuery: created Deferred for " + name + " " + type)
            tr = t.addCallback(self.formatRecords, type, name, flags)
            log.msg(self.pid + " makeQuery: created Callback for " + name + " " + type)
            return tr
            #return r.lookupAddress(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "AAAA"):
            return r.lookupIPV6Address(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "CNAME"):
            return r.lookupCanonicalName(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "MX"):
            return r.lookupMailExchange(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "NAPTR"):
            return r.lookupNamingAuthorityPointer(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "NS"):
            return r.lookupNameservers(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "SOA"):
            return r.lookupAuthority(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "SRV"):
            return r.lookupService(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "TXT"):
            return r.lookupText(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        elif (type == "ALL"):
            return r.lookupAllRecords(name, self.timeouts).addCallback(self.formatRecords, type, name, flags)
        else:
            log.msg(self.pid + " makeQuery called with invalid type")
            return False

    def formatRecords(self, records, type, name, flags):
        result = QueryResult()
        self.currentQueries -= 1
        result.name = name
        result.flags = flags
        if (issubclass(Failure, records.__class__)):
            result.status = records.__str__()
            print("ERROR: {}".format(records.__str__()))
            return result

        answers, authority, additional = records
        result = QueryResult()
        result.status = "NOERROR"
        result.flags = flags
        result.name = name
        result.type = type
        result.data.answers = self.convertRecords(answers)
        result.data.authorities = self.convertRecords(authority)
        result.data.additionals = self.convertRecords(additional)
        return result

    def noQueryStarted(self, name, error, callback, types, flags):
        result = QueryResult()
        result.status = error
        result.flags = flags
        result.name = name
        result.type = " ".join(types)
        callback([result])

    def otherError(self, failure, callback, name, types, flags):
        result = QueryResult()
        result.log = failure.__str__()
        log.err(failure.__str__())
        result.flags = flags
        result.status = "Unknown Error"
        result.type = " ".join(types)
        result.name = name
        callback([result])

    def dnsnameError(self, failure, callback, name, types, flags):
        failure.trap(defer.FirstError)
        failure = failure.value.subFailure
        failure.trap(error.DNSNameError)
        result = QueryResult()
        result.flags = flags
        result.status = "NXDOMAIN"
        result.type = " ".join(types)
        result.name = name
        callback([result])

    def dnsserverError(self, failure, callback, name, types, flags):
        failure.trap(error.DNSServerError)
        result = QueryResult()
        result.status = "DNS Server Error"
        result.type = " ".join(types)
        result.flags = flags
        result.name = name
        callback([result])

    def timeoutError(self, failure, callback, name, types, flags):
        failure.trap(defer.TimeoutError, error.DNSQueryTimeoutError)
        result = QueryResult()
        result.status = "TIMEOUT"
        result.type = " ".join(types)
        result.flags = flags
        result.name = name
        callback([result])

    def getType(self, type, reverse = False):
    
        if reverse:
            for key, val in TwistedResolver.QUERY_TYPES.items():
                if val == type:
                    return key
            return 0
        else:
            return TwistedResolver.QUERY_TYPES.get(type, "UNKNOWN")

    def convertRecords(self, records):
        results = []
        for a in records:
            type = self.getType(a.type)
            payload = a.payload
            record = DnsRecord()
            record.type = self.getType(a.type)
            #RecordType.fromString(self.getType(a.type))

            try:
                record.ttl = a.ttl.__str__()
                record.name = a.name.__str__()
                #record.payload = payload.__str__()
                if (type == "A"):
                    record.answer = socket.inet_ntop(socket.AF_INET, payload.address)
                elif (type == "AAAA"):
                    record.answer = socket.inet_ntop(socket.AF_INET6, payload.address)
                elif (type == "NS"):
                    record.answer = payload.name.__str__()
                elif (type == "CNAME"):
                    record.answer = payload.name.__str__()
                elif (type == "MX"):
                    record.answer = payload.name.__str__()
                    record.attributes["preference"] = payload.preference.__str__()
                elif (type == "SOA"):
                    record.answer = payload.mname.__str__()
                    record.attributes["rname"] = str(payload.rname)
                    record.attributes["serial"] = str(payload.serial)
                    record.attributes["refresh"] = str(payload.refresh)
                    record.attributes["retry"] = str(payload.retry)
                    record.attributes["expire"] = str(payload.expire)
                    record.attributes["minimum"] = str(payload.minimum)
                elif (type == "SRV"):
                    record.answer = payload.target.__str__()
                elif (type == "NAPTR"):
                    record.answer = payload.replacement.__str__()
                elif (type == "TXT"):
                    record.answer = payload.data[0].decode().__str__()
                elif (type == "PTR"):
                    record.answer = payload.name.__str__()                
                else:
                    record.answer = payload.__str__()
            except Exception as e:
                log.msg(traceback.format_exc())

            results.append(record)
        return results

    def reverseNameFromIPAddress(self, address):
        return '.'.join(reversed(address.split('.'))) + '.in-addr.arpa'