from twisted.python import log
from queue import Queue
import os
import json
import sys
import zmq

class Requeue:
    def __init__(self, args):
        self.rules = []
        self.args = args

        #if args.zmq:
        #    context = zmq.Context()
        #    self.queue = context.socket(zmq.PUSH)
        #    self.queue.connect("tcp://" + args.zmqaddr)
        #    log.msg("Opened ZMQ to " + args.zmqaddr)

        # Parse Rules
        for rs in args.rule:
            r = rs.split(";")
            if len(r) != 5:
                log.err("Invalid rule: " + rs)
                continue
            rule = {}
            rule["status"] = r[0].split(",")
            if len(rule["status"][0]) == 0:
                rule["status"] = ["NOERROR"]
            rule["type"] = r[1].split(",")
            if len(rule["type"][0]) == 0:
                rule["type"] = ["A"]
            rule["cont"] = r[2].split(",")
            if len(rule["cont"][0]) == 0:
                rule["cont"] = []
            rule["ncont"] = r[3].split(",")
            if len(rule["ncont"][0]) == 0:
                rule["ncont"] = []
            rule["flags"] = r[4].split(",")
            if len(rule["flags"][0]) == 0:
                rule["flags"] = []
            rule["nflags"] = r[4].split(",")
            if len(rule["nflags"][0]) == 0:
                rule["nflags"] = []
            rule["format"] = r[6].split(",")
            self.rules.append(rule)
        self.presets()

    def presets(self):
        script_dir = os.path.dirname(__file__) 
        for pname in self.args.presetrule:
            rel = os.path.join("requeuePresets", pname + ".pre")
            f = os.path.join(script_dir, rel)
            with open(f) as data_file:    
                try:
                    jrule = json.load(data_file)
                    prules = jrule["rules"]
                    self.rules = self.rules + prules
                except:
                    log.err("Invalid Preset" + sys.exc_info()[0])
        

    def handle(self, res, queue):
        log.msg("Handle Requeue: " + res[0].name)
        for qr in res:
            for rule in self.rules:
                if not qr.status in rule["status"]:
                    # Does not match
                    log.msg("No rule for status " + qr.status)
                    continue

                notmatched = False

                for cont in rule["cont"]:
                    if not cont in qr.name:
                        #print(cont + " does not match " + qr.name)
                        notmatched = True
                        break

                for ncont in rule["ncont"]:
                    if ncont in qr.name:
                        #print(ncont + " matches " + qr.name)
                        notmatched = True
                        break

                for nflag in rule["nflags"]:
                    if nflag in qr.flags:
                        notmatched = True
                        break
                for flag in rule["flags"]:
                    if not flag in qr.flags:
                        notmatched = True
                        break

                if notmatched:
                    continue

                # Handle answers
                answers = qr.data.answers
                qtype = qr.type
                for record in answers:
                    rtype = record.type
                    #log.msg("Type " + rtype)
                    if rtype in rule["type"]:
                        # Matches!
                        ans = record.answer
                        # Requeue all queries
                        for fstr in rule["format"]:
                            query = fstr.format(qr.name, ans, qtype, rtype)
                            #print("Requery: " + query)
                            self.enqueue(query, queue)

                if qr.status != "NOERROR":
                    for fstr in rule["format"]:
                        query = fstr.format(qr.name, "", "", "")
                        #log.err("Requeue: " + query)
                        self.enqueue(query, queue)

                #if len(answers) == 0:
                 #   # Maybe ERROR RESULT?
                  #  if qr.status != "NOERROR":
                   #     if qtype != "":
                    #        if (len(rule["type"]) == 0 or (qtype in rule["type"])):
                     #           for fstr in rule["format"]:
                      #              query = fstr.format(qr.name, "", qtype, "")
                       #             self.enqueue(query, queue)

    def enqueue(self, query, queue):
        #if self.args.zmq:
        log.msg("Requeued: " + query)
        #    test = self.queue.send_string(query)
        #else:
        queue.put(query)
