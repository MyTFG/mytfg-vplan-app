import time
from classes.recordtype import RecordType
from classes.iputils import IpUtils
from classes.ipversion import IpVersion

class DnsRecord(object):
    def __init__(self):
        self.type = "UNDEF"
        self.name = ""
        self.answer = ""
        self.ttl = 0
        self.time = time.strftime('%Y-%m-%d %H:%M:%S')
        self.cls = "IN"
        self.attributes = {}
        self.payload = {}

    def __repr__(self):
        return "DnsRecord()"

    def __str__(self):
        return "{0}    {3}     {4}    {1}    {2}   ({5})".format(self.name, self.type, self.answer, self.ttl, self.cls, self.attributes.__str__())

    #def requery(self, resolver, cb):

    def setTtl(self, ttl):
        self.ttl = ttl

    def getTtl(self):
        return self.ttl

    def setType(self, type):
        self.type = type

    def getType(self):
        return self.type

    def setName(self, name):
        self.name = name

    def getName(self):
        return self.name

    def setCls(self, cls):
        self.cls = cls

    def getCls(self):
        return self.cls

    def setAnswer(self, res):
        self.answer = res

    def getAnswer(self):
        return self.answer
        
    def setAttr(self, attr, val):
        self.attributes[attr] = val
    
    def getAttr(self, attr):
        return self.attributes.get(attr, None)

    def setIp(self, ip):
        self.answer = ip
        version = IpUtils.version(ip)
        if (version == IpVersion.IPv4):
            self.rtype = RecordType.A
        elif (version == IpVersion.IPv6):
            self.rtype = RecordType.AAAA
