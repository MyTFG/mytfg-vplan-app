import time
import sys
import os
import ujson as json
import json as defjson
from queue import Queue, Empty
from select import select

import zmq

from classes.resolver.twisted import TwistedResolver
from classes.statistics import Statistics
from classes.requeue import Requeue
from twisted.internet import reactor
from twisted.internet import task
from twisted.python import log
from asyncio import QueueEmpty

from multiprocessing.pool import Pool

class AdnsResolver(object):
    def __init__(self, args):
        self.lib = "twisted"
        self.pid = "PID " + str(os.getpid())
        self.args = args
        self.sched = None
        self.statistics = Statistics(args)
        # Extract library
        if (args.lib):
            self.lib = args.lib

        # The queue holding all queries
        if not args.queue and not args.zmq:
            self.closable = True
            self.defqueue = Queue()
            self.expectStdin = True
        else:
            if not args.queue:
                self.defqueue = Queue()
            else:                
                self.defqueue = args.queue
            log.msg(str(self.defqueue))
            if args.zmq:
                context = zmq.Context()
                self.queue = context.socket(zmq.PULL)
                self.queue.connect("tcp://" + args.zmqaddr)
            self.closable = True
            self.expectStdin = False

        self.allowedEmpties = args.wait
        self.empties = 0
        
        self.pool = None

        self.callback = None
        self.options = {}

        if (args.calls > 0):
            self.max_queries = args.calls
        else:
            self.max_queries = 1000 # Good value?!

        self.current_queries = 0
        self.completed_queries = 0

        self.requeue = Requeue(args)

        if (self.lib == "twisted"):
            self.resolver = TwistedResolver(args)
        else:
            raise ValueError("Invalid library")

    def readQueue(self):
        if self.expectStdin:
            query = sys.stdin.readline()
            if query:
                return query
            else:
                self.expectStdin = False
        resp = False
        try:
            if self.args.zmq:
                resp = self.queue.recv_string(zmq.NOBLOCK)
            else:
                resp = self.defqueue.get_nowait()
            resp = resp.strip()
            #log.msg(self.pid + ": ReadQueue got " +str(resp) + " from QUEUE")
        except Empty:
            resp = False
        except zmq.ZMQError:
            try:                
                resp = self.defqueue.get_nowait()
            except Empty:
                resp = False

        return resp

    def readstdin(self):
        if (self.lib == "twisted"):
            if self.current_queries >= self.args.calls:
                log.err("More than " + self.args.calls + " active calls - waiting...")
                return

            name = self.readQueue()
            if not name:
                #log.msg(self.pid + ": No input from QUEUE")
                self.empties += 1
                if self.empties < self.allowedEmpties:
                    return
                #self.sched.stop()
                if self.current_queries <= 0:
                    #self.sched.stop()
                    self.sched.stop()
                    if reactor.running:
                        reactor.stop()
                    self.statistics.save()
                    log.msg(self.pid + " TERMINATING! No more work to do")
                else:                    
                    log.msg(self.pid + " Would like to terminate, but " + str(self.current_queries) + " queries still pending")
                return
            self.empties = 0

            name = name.strip()
            # Skip empty lines
            if (name == ""):
                return
            # Skip deadlock avoidance char
            if (name == "?"):
                return

            types = self.options["types"]
            opts = self.options
            opts["flags"] = []
            splitted = name.split(" ")
            first = True
            if len(splitted) > 1:
                #opts["types"] = splitted[1:]
                for opt in splitted[1:]:
                    if len(opt) == 0:
                        continue
                    if opt[0] == "@":
                        opts["flags"].append(opt)
                    else:
                        if first:
                            first = False
                            opts["types"] = [opt]
                        else:
                            opts["types"].append(opt)
                name = splitted[0]

            nq = None
            #log.err(str(opts))

            log.msg(self.pid + " Got from Queue: " + name)

            self.current_queries = self.current_queries + 1
            self.statistics.query(name, opts)
            log.msg(self.pid + " Trying to Query: " + name)
            self.resolver.query(name, opts, lambda res: self.query_done(res, nq, self.callback))

            log.msg(self.pid + " Issued Query: " + name)
        return True

    def query_done(self, res, nq, cb):
        if (self.lib == "pycares"):
            err = res[0]["error"]
            self.handle_queue(True, err, nq)
        elif (self.lib == "twisted"):
            self.current_queries = self.current_queries - 1
            self.completed_queries = self.completed_queries + 1
            log.msg(self.pid + " ## " + str(self.current_queries) + " / " + str(self.completed_queries))
            #print("Completed queries: {}".format(self.completed_queries)) 
        self.statistics.result(res)
        # Requeue tasks
        self.requeue.handle(res, self.defqueue)
        # Output
        cb(res)
        sys.stdout.flush()

    def runStdin(self, options, callback):
        if (self.lib == "twisted"):
            self.options = options
            self.callback = callback
            if self.callback == None:
                self.callback = self.jsonCallback
            self.sched = task.LoopingCall(self.readstdin)
            #self.sched.start(self.args.interval)
            self.sched.start(self.args.interval)
            #stdio.StandardIO(StdIoHandler(self))
            reactor.run()

    def jsonCallback(self, result):
        for res in result:
            output = defjson.dumps(res, default=lambda o: o.__dict__)
            print(output, flush=True)
            sys.stdout.flush()

    def cancel(self):
        log.msg("Stopping TDNS")
        if self.pool:
            self.pool.terminate()
        reactor.stop()
