import argparse
from classes.resolver.twisted import TwistedResolver

class ArgParser(object):
    def __init__(self):
        self.progname = "TDNS"
        self.versionstr = "0.3"
        self.progversion = "{0} {1}".format(self.progname, self.versionstr)
        self.parser = argparse.ArgumentParser(description="Perform asynchronous DNS requests.", prog=self.progname)
        #self.query()
        self.type()
        self.statistics()
        self.interval()
        #self.input()
        self.nameservers()
        self.timeout()
        self.tries()
        #self.maxqueries()
        self.calls()
        #self.rotate()
        self.version()
        #self.errorcorrection()
        self.library()
        self.format()
        self.rule()
        self.presets()
        self.threads()
        self.zmq()
        self.logging()
        self.wait()

    def getParser(self):
        return self.parser

    def query(self):
        p = self.parser
        p.add_argument("--query", "-q", metavar="QUERY", action="append", 
            help="Hostname/IP to query (Multi-Option)")

    def type(self):
        p = self.parser

        types = []
        for key, val in TwistedResolver.QUERY_TYPES.items():
            types.append(val)

        p.add_argument("--type", "-t", action="append", default=[], 
            choices=types, 
            help="Query-Types (Record-Types). Default: A")

    def format(self):
        p = self.parser
        p.add_argument("--format", "-fm", action="store", default="json", 
            choices=["json", "raw"], 
            help="Output format. Default: JSON")
    
    def statistics(self):
        p = self.parser
        p.add_argument("--statistics", action="store",
            help="File for statistics (appended). Default: None")

    def interval(self):
        p = self.parser
        p.add_argument("--interval", metavar="SEC", 
            action="store", 
            default="0.001", 
            help="Number of Seconds (float) to wait between each query (Default: 0.001s)",
            type=float)

    def library(self):
        p = self.parser
        p.add_argument("--lib", action="store", default="twisted", 
            choices=["pycares", "twisted"], 
            help="Library to use. Default: twisted")

    def input(self):
        p = self.parser
        p.add_argument("--inputfile", "-i", action="store", 
            metavar="FILE",
            type=open, 
            help="Input file containing a list of domains")

    def nameservers(self):
        p = self.parser
        p.add_argument("--nameserver", "-ns", metavar="NS",
            help="Nameservers to use (Multi-Option)",
            action="append")

    def timeout(self):
        p = self.parser
        p.add_argument("--timeouts", metavar="SECS", 
            nargs="+", 
            default=[5.0],
            type=float, 
            help="List of Seconds (float) to wait for each Nameserver")

    def tries(self):
        p = self.parser
        p.add_argument("--tries", metavar="NUM", 
            action="store", 
            default="1", 
            help="Number of retries per Nameserver (Default 1)",
            type=int)


    def version(self):
        p = self.parser
        p.add_argument("--version", action="version", version=self.progversion)

    def maxqueries(self):
        p = self.parser
        p.add_argument("--maxqueries", "-mq", metavar="NUM", 
            action="store", 
            default="-1", 
            help="Max. number of queries to execute (For lists as input)",
            type=int)

    def threads(self):
        p = self.parser
        p.add_argument("--threads", metavar="NUM", 
            action="store", 
            default="1", 
            help="Number of worker threads. (Default 1)",
            type=int)

    def calls(self):
        p = self.parser
        p.add_argument("--calls", metavar="NUM",
            action="store",
            default="3000",
            help="Max. number of concurrent queries per process (Default: 3000)",
            type=int)


    def wait(self):
        p = self.parser
        p.add_argument("--wait", metavar="NUM",
            action="store",
            default="1",
            help="Max. number of concurrent failed queue reads. Use with zmq only.",
            type=int)

    def rotate(self):
        p = self.parser
        p.add_argument("--rotate", 
                action="store_true",
                help="Set, if nameserver should be rotated")

    def errorcorrection(self):
        p = self.parser
        p.add_argument("--ec", 
                action="store_true",
                help="Set, if ZDNS should retry on Timeouts due to Server overload (ZDNS+)")

    def logging(self):
        p = self.parser
        p.add_argument("--log",
                action="store_true",
                help="Set to enable logging to stderr")


    def zmq(self):
        p = self.parser
        p.add_argument("--zmq",
                action="store_true",
                help="Set, if TDNS should use ZeroMQ instead of the default python Queue.\nConsider using zmqaddr and zmqnobind as well.")

        p.add_argument("--zmqaddr",
                action="store",
                help="Set IP:Port to use for the ZeroMQ socket. Default: 127.0.0.1:5557",
                default="127.0.0.1:5557")

        p.add_argument("--zmqnofill",
                action="store_true",
                help="Use this if the main process should not read from stdin. Use this when a queue on another host is used.")
    
    def rule(self):
        p = self.parser
        p.add_argument("--rule", "-r", action="append", default=[],
            help="Requeue Rules. 'STATUS;A;contains;containsnot;flags;nflags;{0} AAAA'")

    def presets(self):
        p = self.parser
        p.add_argument("--presetrule", "-p", action="append", default=[],
            help="File with JSON Rule(s)")
