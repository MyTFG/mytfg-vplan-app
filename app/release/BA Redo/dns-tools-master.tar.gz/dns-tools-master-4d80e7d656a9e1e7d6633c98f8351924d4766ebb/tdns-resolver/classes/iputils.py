import socket
from classes.ipversion import IpVersion

class IpUtils(object):
    @staticmethod
    def is_ip(addr):
        return (IpUtils.is_valid_ipv4_address(addr) or IpUtils.is_valid_ipv6_address(addr))

    @staticmethod
    def is_valid_ipv4_address(addr):
        try:
            socket.inet_pton(socket.AF_INET, addr)
        except socket.error:
            return False
        return True

    @staticmethod
    def is_valid_ipv6_address(addr):
        try:
            socket.inet_pton(socket.AF_INET6, addr)
        except socket.error:
            return False
        return True

    @staticmethod
    def version(addr):
        if (IpUtils.is_valid_ipv4_address(addr)):
            return IpVersion.IPv4
        elif (IpUtils.is_valid_ipv6_address(addr)):
            return IpVersion.IPv6
        else:
            return IpVersion.UNDEF